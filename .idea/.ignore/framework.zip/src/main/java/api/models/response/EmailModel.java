package api.models.response;

import java.util.ArrayList;

public class EmailModel {
    public int last;
    public String total;
    public ArrayList<Msg> msgs;

    public static class Msg {
        public String uid;
        public String ib;
        public String f;
        public String s;
        public boolean d;
        public ArrayList<Object> at;
        public int r;
        public boolean ru;
        public String fe;
        public String rf;
        public String ii;
        public String av;
    }
}