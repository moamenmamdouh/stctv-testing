package api.enums;

import lombok.Getter;


public enum ChooseCard {
    Plan("Plan"),
    Card("Card"),
    AddtoPlan("AddtoPlan");


    @Getter
    private final String value;

    ChooseCard(String value) {
        this.value = value;
    }
}

