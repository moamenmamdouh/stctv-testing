package api.enums;

import lombok.Getter;


public enum Endpoints {
    Anonymous_Authorization_Token("/authorization/authorizationToken");

    @Getter
    private final String value;

    Endpoints(String value) {
        this.value = value;
    }
}
