package api.restwrapper;


import api.enums.Endpoints;

import java.util.Map;
import java.util.Properties;

import static api.restwrapper.PropertiesLoader.readPropertyFile;
import static io.restassured.RestAssured.given;

public class RestWrapper {
    private static Properties urlProps = readPropertyFile("config/config.properties");

    public static <T> T restPost(Endpoints endpoint, Map<String, String> headers, Object bodyData, Class<T> responseClass) {
        return given()
                .relaxedHTTPSValidation()
                .headers(headers)
                .body(bodyData)
                .when()
                .post(System.getProperty("api_url", urlProps.getProperty("api_url")).concat(endpoint.getValue()))
                .then()
                .extract()
                .as(responseClass);
    }

    public static <T> T restPostWithAuth(Endpoints endpoint, String authUsername, String authPassword, String URL, Map<String, String> headers, Object bodyData, Class<T> responseClass) {
        return given()
                .auth().basic(authUsername, authPassword)
                .relaxedHTTPSValidation()
                .headers(headers)
                .body(bodyData)
                .when()
                .post(URL.concat(endpoint.getValue()))
                .then()
                .extract()
                .as(responseClass);
    }

    public static <T> T restGet(Endpoints endpoint, Map<String, String> headers, Class<T> responseClass) {
        return given()
                .relaxedHTTPSValidation()
                .headers(headers)
                .when()
                .get(System.getProperty("api_url", urlProps.getProperty("api_url")).concat(endpoint.getValue()))
                .then()
                .extract()
                .as(responseClass);
    }

    public static <T> T restGetEmail(Class<T> responseClass) {
        return given()
                .when()
                .get("https://getnada.com/api/v1/inboxes/vodafoneotac@getnada.com")
                .then()
                .extract()
                .as(responseClass);
    }

    public static String restGetOtac(String mailUUID) {
        return given()
                .when()
                .get("https://getnada.com/api/v1/messages/html/" + mailUUID)
                .then()
                .extract()
                .asString();
    }

    public static <T> T restGetWithRequestParameters(Endpoints endpoint, Map<String, String> headers, Map<String, String> queryParameters, Class<T> responseClass) {
        return given()
                .relaxedHTTPSValidation()
                .headers(headers)
                .queryParams(queryParameters)
                .when()
                .get(System.getProperty("api_url", urlProps.getProperty("api_url")).concat(endpoint.getValue()))
                .then()
                .extract()
                .as(responseClass);
    }

    public static <T> T restGet(String endpoint, Map<String, String> headers, Class<T> responseClass) {
        return given()
                .relaxedHTTPSValidation()
                .headers(headers)
                .when()
                .get(System.getProperty("api_url", urlProps.getProperty("api_url")).concat(endpoint))
                .then()
                .extract()
                .as(responseClass);
    }
}
