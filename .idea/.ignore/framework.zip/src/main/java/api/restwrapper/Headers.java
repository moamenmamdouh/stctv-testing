package api.restwrapper;

public class Headers {

}
