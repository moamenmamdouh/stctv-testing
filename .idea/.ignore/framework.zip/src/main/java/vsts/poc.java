package vsts;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.codec.binary.Base64;
import org.jsoup.Jsoup;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

@Deprecated
public class poc {

    public void addTagTestPass(int workItem) throws IOException {
        URL url = new URL("https://dev.azure.com/vfuk-digital/Digital/_apis/wit/workItems/" + workItem + "?api-version=6.0");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestProperty("X-HTTP-Method-Override", "PATCH");
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(5000);
        connection.setDoOutput(true);
        connection.setRequestProperty("Content-Type", "application/json-patch+json");
        String auth = "ali.adelsaeed@vodafone.com" + ":" + "f2nvywppv5v5nzckx4gof2zpfdv2xklufby5kd6mypkbcxupptxa";
        byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(StandardCharsets.UTF_8));
        String authHeaderValue = "Basic " + new String(encodedAuth);
        connection.setRequestProperty("Authorization", authHeaderValue);
        OutputStreamWriter out = new OutputStreamWriter(connection.getOutputStream());
        out.write("[\n" +
                "    {\n" +
                "        \"op\": \"add\",\n" +
                "        \"path\": \"/fields/System.Tags\",\n" +
                "        \"value\": \"PASSED; Tobi Automation; Automated Successfully\"\n" +
                "    }\n" +
                "]");
        out.flush();
        out.close();
        System.out.println(connection.getResponseCode());
    }

    public void addTagTestFailed(int workItem) throws IOException {
        URL url = new URL("https://dev.azure.com/vfuk-digital/Digital/_apis/wit/workItems/" + workItem + "?api-version=6.0");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestProperty("X-HTTP-Method-Override", "PATCH");
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(5000);
        connection.setDoOutput(true);
        connection.setRequestProperty("Content-Type", "application/json-patch+json");
        String auth = "ali.adelsaeed@vodafone.com" + ":" + "f2nvywppv5v5nzckx4gof2zpfdv2xklufby5kd6mypkbcxupptxa";
        byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(StandardCharsets.UTF_8));
        String authHeaderValue = "Basic " + new String(encodedAuth);
        connection.setRequestProperty("Authorization", authHeaderValue);
        OutputStreamWriter out = new OutputStreamWriter(connection.getOutputStream());
        out.write("[\n" +
                "    {\n" +
                "        \"op\": \"add\",\n" +
                "        \"path\": \"/fields/System.Tags\",\n" +
                "        \"value\": \"FAILED; Tobi Automation; Automated Successfully\"\n" +
                "    }\n" +
                "]");
        out.flush();
        out.close();
        System.out.println(connection.getResponseCode());
    }

    public void getTestCase() throws IOException {
        URL url = new URL("https://vfuk-digital.visualstudio.com/Digital/_apis/wit/workitems/311166?api-version=6.0");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.setRequestProperty("accept", "application/json");
        String auth = "ali.adelsaeed@vodafone.com" + ":" + "f2nvywppv5v5nzckx4gof2zpfdv2xklufby5kd6mypkbcxupptxa";
        byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(StandardCharsets.UTF_8));
        String authHeaderValue = "Basic " + new String(encodedAuth);
        connection.setRequestProperty("Authorization", authHeaderValue);
        InputStream responseStream = connection.getInputStream();
        ObjectMapper mapper = new ObjectMapper();
        WorkItem workItem = mapper.readValue(responseStream, WorkItem.class);
        String plainText = Jsoup.parse(workItem.fields.Steps).wholeText();
        PrintWriter writer = new PrintWriter("sample.feature", "UTF-8");
        writer.println(plainText);
        writer.close();
    }
}
