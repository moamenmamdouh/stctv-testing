package vsts;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.codec.binary.Base64;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.safety.Safelist;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Deprecated
public class VstsWrapper {

    public static String cleanPreserveLineBreaks(String bodyHtml) {
        String prettyPrintedBodyFragment = Jsoup.clean(bodyHtml, "", Safelist.none().addTags("br", "p"), new Document.OutputSettings().prettyPrint(true));
        return Jsoup.clean(prettyPrintedBodyFragment, "", Safelist.none(), new Document.OutputSettings().prettyPrint(false));
    }

    public int getWorkItem(int workItem) throws IOException {
        URL url = new URL("https://vfuk-digital.visualstudio.com/Digital/_apis/wit/workitems/" + workItem + "?api-version=6.0");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.setRequestProperty("accept", "application/json");
        String auth = "ali.adelsaeed@vodafone.com" + ":" + "f2nvywppv5v5nzckx4gof2zpfdv2xklufby5kd6mypkbcxupptxa";
        byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(StandardCharsets.UTF_8));
        String authHeaderValue = "Basic " + new String(encodedAuth);
        connection.setRequestProperty("Authorization", authHeaderValue);
        InputStream responseStream = connection.getInputStream();
        ObjectMapper mapper = new ObjectMapper();
        WorkItem workItemJson = mapper.readValue(responseStream, WorkItem.class);
        String plainText = cleanPreserveLineBreaks(workItemJson.fields.Description).replace("&nbsp;", " ");
        String plain = plainText.replace("\n\"", "\"");
        String plainTextNew = plain.replace("\"\"\"", "\n\"\"\"\n").replace("\n\n\"\"\"", "\n\"\"\"").replace("\"\"\"\n\n", "\"\"\"\n").replace("\n\n\n\"\"\"", "\n\"\"\"").replace("\"\"\"\n\n\n", "\"\"\"\n");
        String plainTextNewNew = plainTextNew.replace("\"And", "\"\nAnd").replace("\"Given", "\"\nGiven").replace("\"When", "\"\nWhen").replace("\"Then", "\"\nThen");
        String ReplaceAnd = plainTextNewNew.replace("&amp;", "&");
        String afterNewLine = ReplaceAnd.replaceAll("\"\"\"\n" + "(?m)^[ \t]*\r?\n", "\"\"\"\n");
        String featureText = afterNewLine.replaceAll("(?m)^[ \t]*\r?\n" + "\"\"\"", "\"\"\"");
        PrintWriter writer = new PrintWriter("src/test/resources/feature_files/flows/" + workItem + ".feature", "UTF-8");
        String runTag = getRandomTag();
        writer.println(runTag + " @" + workItem + "\n" +
                "Feature: " + workItemJson.fields.Title + " - " + workItem + "\n" +
                "\n" +
                "Background: Accept cookies\n" +
                "Given Accept all cookies\n");
        String[] addrLines = featureText.split("\n");
        StringBuffer formatedAddress = new StringBuffer();
        for (String line : addrLines) {
            formatedAddress.append(line.trim() + "\n");
        }
        writer.println(formatedAddress);
        writer.close();
        return connection.getResponseCode();
    }

    public List<Integer> runSearchQuery() throws IOException {
        List<Integer> workItemIds = new ArrayList<>();
        URL url = new URL("https://dev.azure.com/vfuk-digital/Digital/_apis/wit/wiql/bf76e91a-920e-4a56-bdef-cb0bbea30417?api-version=6.0&$top=1000");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.setRequestProperty("accept", "application/json");
        String auth = "ali.adelsaeed@vodafone.com" + ":" + "f2nvywppv5v5nzckx4gof2zpfdv2xklufby5kd6mypkbcxupptxa";
        byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(StandardCharsets.UTF_8));
        String authHeaderValue = "Basic " + new String(encodedAuth);
        connection.setRequestProperty("Authorization", authHeaderValue);
        InputStream responseStream = connection.getInputStream();
        ObjectMapper mapper = new ObjectMapper();
        SearchQueryResponseModel searchQueryResponse = mapper.readValue(responseStream, SearchQueryResponseModel.class);
        for (int idsCount = 0; idsCount < searchQueryResponse.workItems.size(); idsCount++) {
            workItemIds.add(searchQueryResponse.workItems.get(idsCount).id);
        }
        return workItemIds;
    }


    public void addTags(int workItem) throws IOException {
        URL url = new URL("https://dev.azure.com/vfuk-digital/Digital/_apis/wit/workItems/" + workItem + "?api-version=6.0");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestProperty("X-HTTP-Method-Override", "PATCH");
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(5000);
        connection.setDoOutput(true);
        connection.setRequestProperty("Content-Type", "application/json-patch+json");
        String auth = "ali.adelsaeed@vodafone.com" + ":" + "f2nvywppv5v5nzckx4gof2zpfdv2xklufby5kd6mypkbcxupptxa";
        byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(StandardCharsets.UTF_8));
        String authHeaderValue = "Basic " + new String(encodedAuth);
        connection.setRequestProperty("Authorization", authHeaderValue);
        OutputStreamWriter out = new OutputStreamWriter(connection.getOutputStream());
        out.write("[\n" +
                "    {\n" +
                "        \"op\": \"add\",\n" +
                "        \"path\": \"/fields/System.Tags\",\n" +
                "        \"value\": \"Tobi Automation; Automated Successfully\"\n" +
                "    }\n" +
                "]");
        out.flush();
        out.close();
        System.out.println(connection.getResponseCode());
    }


    public String getRandomTag() {
        // TODO Remove no longer need Multiple run tag
        String[] tags = {"@Run", "@Run", "@Run"};
        Random generator = new Random();
        int randomIndex = generator.nextInt(tags.length);
        return tags[randomIndex];
    }
}
