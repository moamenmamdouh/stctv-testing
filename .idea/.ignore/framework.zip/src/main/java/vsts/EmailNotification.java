package vsts;

@Deprecated
public class EmailNotification {

    public void sendEmailNotification() {
    }
}