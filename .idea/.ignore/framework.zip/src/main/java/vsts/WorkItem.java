package vsts;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@Deprecated
@JsonIgnoreProperties(ignoreUnknown = true)
public class WorkItem {

    public final FieldsResponseModel fields;
    public final int id;


    public WorkItem(@JsonProperty("fields") FieldsResponseModel fields, @JsonProperty("id") int id) {
        this.fields = fields;
        this.id = id;
    }
}
