package vsts;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@Deprecated
@JsonIgnoreProperties(ignoreUnknown = true)
public class FieldsResponseModel {

    public final String Description;
    public final String Title;
    public final String Steps;


    public FieldsResponseModel(@JsonProperty("System.Description") String Description, @JsonProperty("Microsoft.VSTS.TCM.Steps") String Steps, @JsonProperty("System.Title") String Title) {
        this.Description = Description;
        this.Title = Title;
        this.Steps = Steps;
    }
}
