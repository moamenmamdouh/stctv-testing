package vsts;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@Deprecated
@JsonIgnoreProperties(ignoreUnknown = true)
public class SearchQueryResponseModel {

    public final List<WorkItem> workItems;

    public SearchQueryResponseModel(@JsonProperty("workItems") List<WorkItem> workItems) {
        this.workItems = workItems;
    }
}
