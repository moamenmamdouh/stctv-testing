package com.cucmber.page.common;

import api.enums.ChooseCard;
import api.models.response.EmailModel;
import api.restwrapper.RestWrapper;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import java.time.LocalTime;
import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.cucmber.core.helper.PropertiesLoader.readPropertyFile;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class CommonHelper extends CommonPo {

    private final static Logger Log = Logger.getLogger(CommonHelper.class.getName());
    public static int Count = 0;
    private static By lastVerifiedTobiResponseLocator;
    private final Properties props;
    private final String url;
    private boolean newflow = false;

    public CommonHelper(final WebDriver driver) {
        super(driver);
        props = readPropertyFile("config/config.properties");
        url = System.getProperty("url", props.getProperty("application.url"));
    }

    public void acceptCookies() {
        try {
            waitForVisible(acceptCookiesFrame);
            clickElement(acceptCookiesButton);
        } catch (Exception e) {
            System.out.println("Cookies not displayed");
        }
        LocalTime waitingStartTime = java.time.LocalTime.now();
        try {
            itsWait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("[aria-label='Send message']")));
        } catch (NoSuchElementException e) {
            assertFail("FAIL: waited for the visibility of send button from " + waitingStartTime + " until " + java.time.LocalTime.now() + " but it didn't appear");
        }
    }

    public void customerSays(String customerText) {
        waitForVisible(userInputField);
        typeEditBox(userInputField, customerText);
        clickElement(sendButton);
        ++Count;
    }

    public void chatDisplayed() {
            try {
                waitForVisibleTextByIndex(Integer.toString(0), 5);
            } catch (Exception e) {
                driver.navigate().refresh();
                waitForVisibleTextByIndex(Integer.toString(0), 5);
            }
        WebElement firstMessage = driver.findElement(By.id("message-index-0"));
        String newHelloMessage = "Hi! I’m TOBi, Vodafone’s chatbot.";
        if (firstMessage.getText().contains(newHelloMessage)) {
               try {
                   waitForVisibleTextByIndex(Integer.toString(2), 5);
                   Count = 2;
                   newflow = true;
               } catch (Exception e) {
                   driver.navigate().refresh();
                   waitForVisibleTextByIndex(Integer.toString(2), 5);
                   Count = 2;
                   newflow = true;
               }
        }
    }

    public void hyperlinkCheck(String hyperlink) {
        assertElementIsVisible(itsDriver.findElement(By.id("tobi-ui-root")).findElement(By.cssSelector("[href='" + hyperlink + "']")), hyperlink);
    }

    /**
     * Check if that hyperlink with that linkText exists in any of Tobi responses.
     *
     * @param hyperlink The hyperlink to be found.
     * @param linkText  The link text of the hyperlink.
     */
    public void hyperlinkCheck(String hyperlink, String linkText) {
        assertElementText(itsDriver.findElement(By.id("tobi-ui-root")).findElement(By.cssSelector("[href='" + hyperlink + "']")), linkText);
    }

    @Deprecated
    public void verifyTobiLastResponse(String tobiResponse) {
        implicitWaitAndSleep(25);
        waitForVisible(tobiSays.get(tobiSays.size() - 1));
        assertElementText(tobiSays.get(tobiSays.size() - 1), tobiResponse);
    }

    public void verifyTobiResponsesContain(String tobiResponse) {
        try {
            ++Count;
            waitForTextWithIndexToBeVisible(Count);
        } catch (Exception e) {
            assertFail(String.format("FAIL: Tobi new message '%s' with index '%s' did not display in time", tobiResponse, Count));
        }
        lastVerifiedTobiResponseLocator = checkIfTextOfLastElementIsPresentInAList(Count, tobiResponse);
    }


    public void verifyTobiResponsesContainForCards(String tobiResponse) {
        implicitWait(20);
        try {
            Count = Count + 1;
            waitForTextWithIndexToBeVisible(Count);
        } catch (Exception e) {
            assertFail(String.format("FAIL: Tobi new message '%s' with index '%s' did not display in time", tobiResponse, Count));
        }
        //  lastVerifiedTobiResponseWebElement = checkIfTextOfAnElementIsPresentInAList(tobiSays(), tobiResponse);
        lastVerifiedTobiResponseLocator = checkIfTextOfLastElementIsPresentInAList(Count, tobiResponse);
    }

    /**
     * Check if the last response message that was found by "Verify Tobi Responses Contain" also contains that text.
     *
     * @param tobiResponse The text to be found.
     */
    public void verifyTobiResponseAlsoContains(String tobiResponse) {
        if (lastVerifiedTobiResponseLocator != null) {
            WebElement lastVerifiedElement = itsDriver.findElement(lastVerifiedTobiResponseLocator);
            assertCheckIfTrue(String.format("FAIL: Text '%s' isn't found in the element : %s ", tobiResponse, lastVerifiedElement.getText()), lastVerifiedElement.getText().contains(tobiResponse));
        } else assertFail("FAIL: Element wasn't found");
    }

    /**
     * Check if the last response message that was found by "Verify Tobi Responses Contain" also contains that text.
     *
     * @param tobiResponse The text to be found.
     * @param failureMsg   The message to be displayed in case of failure.
     */
    public void verifyTobiResponseAlsoContains(String tobiResponse, String failureMsg) {
        if (lastVerifiedTobiResponseLocator != null) {
            WebElement lastVerifiedElement = itsDriver.findElement(lastVerifiedTobiResponseLocator);
            assertCheckIfTrue(String.format(failureMsg, lastVerifiedElement.getText()), lastVerifiedElement.getText().contains(tobiResponse));
        } else assertFail("FAIL: Element wasn't found");
    }

    /**
     * Check if the last response message that was found by "Verify Tobi Responses Contain" also contains that text.
     *
     * @param tobiResponse    The text to be found.
     * @param failureMsg      The message to be displayed in case of failure.
     * @param descriptiveText The readable chunk of text we are searching for.
     */
    public void verifyTobiResponseAlsoContains(String tobiResponse, String failureMsg, String descriptiveText) {
        if (lastVerifiedTobiResponseLocator != null) {
            WebElement lastVerifiedElement = itsDriver.findElement(lastVerifiedTobiResponseLocator);
            assertCheckIfTrue(String.format(failureMsg, descriptiveText, lastVerifiedElement.getText()), lastVerifiedElement.getText().contains(tobiResponse));
        } else assertFail("FAIL: Element wasn't found");
    }

    /**
     * Check if the last response message that was found by "Verify Tobi Responses Contain" doesn't contains that text.
     *
     * @param tobiResponse The text to be found.
     * @param failureMsg   The message to be displayed in case of failure.
     */
    public void verifyTobiResponseAlsoDoesntContain(String tobiResponse, String failureMsg) {
        if (lastVerifiedTobiResponseLocator != null) {
            WebElement lastVerifiedElement = itsDriver.findElement(lastVerifiedTobiResponseLocator);
            assertCheckIfFalse(String.format(failureMsg, lastVerifiedElement.getText()), lastVerifiedElement.getText().contains(tobiResponse));
        } else assertFail("FAIL: Element wasn't found");
    }

    /**
     * Check if the last response message that was found by "Verify Tobi Responses Contain" also contains that hyperlink with the linkText.
     *
     * @param hyperlink The hyperlink to be found.
     * @param linkText  The link text of the hyperlink.
     */
    public void verifyTobiResponseContainsHyperlink(String hyperlink, String linkText) {
        if (lastVerifiedTobiResponseLocator != null) {
            WebElement lastVerifiedElement = itsDriver.findElement(lastVerifiedTobiResponseLocator);
            assertElementText(lastVerifiedElement.findElement(By.cssSelector("[href='" + hyperlink + "']")), linkText);
        } else assertFail("FAIL: Element wasn't found");
    }

    public void verifyTobiResponsesNotContain(String tobiResponse) {
        implicitWaitAndSleep(25);
        checkIfTextOfAnElementIsNotPresentInAList(tobiSays, tobiResponse);
    }

    public void customerClickOn(String buttonText) {
        clickOnButtonWithText(buttonText, false);
    }

    public void customerClickOnInLastResponse(String buttonText) {
        clickOnButtonWithText(buttonText, true);
    }

    public void clickOnButtonWithText(String buttonText, boolean lastResponse) {
        int repeat = 0;
        while (repeat <= 3) {
            try {
                WebElement myButton;
                if (lastResponse) {
                    myButton = buttonWithValueInCurrentResponse(buttonText);
                } else {
                    myButton = buttonWithValue(buttonText);
                }
                if (myButton != null) clickElement(myButton);
                else assertFail(String.format("No buttons found with such text: '%s'", buttonText));
                break;
            } catch (StaleElementReferenceException e) {
                e.printStackTrace();
            }
            ++repeat;
        }
        ++Count;
    }

    public void customerClicksOnHyperlinkString(String hyperlink) {
        WebElement element = itsDriver.findElement(By.id("tobi-ui-root")).findElement(By.xpath("//button[contains(text(),'" + hyperlink + "')]"));
        element.click();
        ++Count;
    }

    /**
     * Enters the phone number into the phone number field in the phone number screen in DXIDM.
     *
     * @param ctn The phone number
     */
    public void customerSendsCTN(String ctn) {
        waitForVisible(ctnField);
        typeEditBox(ctnField, ctn);
        clickElement(continue_button);
    }

    /**
     * Login DXIDM with username and password, without switching focus away from DXIDM iframe.
     *
     * @param username username to sign in with
     * @param password password to sign in with
     */
    public void DXIDMLoginUsernamePassword(String username, String password) {
        waitForVisible(usernameField);
        typeEditBox(usernameField, username);
        clickElement(continue_button);
        waitForVisible(passwordField);
        typeEditBox(passwordField, password);
        clickElement(login_button);
    }

    /**
     * Login DXIDM with username and password and switch focus from DXIDM iframe to the chat after closing the DXIDM.
     * To be used in LOA1 and LOA2 cases only.
     *
     * @param username username to sign in with
     * @param password password to sign in with
     */
    public void DXIDMLoginLAO2usernamePassword(String username, String password) {
        DXIDMLoginUsernamePassword(username, password);
        driver.switchTo().defaultContent();
    }

    public void DXIDMLoginUsername(String username) {
        String newMessage = "How would you like to complete security?";
        if (newflow) {
            verifyTobiResponsesContain(newMessage);
            customerClickOn("Log in with my Username and Password");
            verifyTobiResponsesContain("Great, I'll launch a secure pop-up for you to enter your Username and Password now.");
        }
        switchToIFrameAcceptCookieDXIDM();
        DXIDMLoginLAO2usernamePassword(username, "testing1");
        verifyTobiResponsesContain("Thanks, that's the security part completed.");
    }

    public String getOtac() {
        implicitWaitAndSleep(20);
        String uuid = RestWrapper.restGetEmail(EmailModel.class).msgs.get(0).uid;
        String emailBody = RestWrapper.restGetOtac(uuid);
        Pattern p = Pattern.compile("(?<=Message: )(.*)(?= is your code)");
        Matcher m = p.matcher(emailBody);
        String otac = "";
        if (m.find()) {
            otac = m.group(1);
        }
        System.out.println(emailBody);
        System.out.println(otac);
        return otac;
    }

    public void customerSendsOtac(String otac) {
        waitForVisible(otac_01);
        typeEditBox(otac_01, Character.toString(otac.charAt(0)));
        typeEditBox(otac_02, Character.toString(otac.charAt(1)));
        typeEditBox(otac_03, Character.toString(otac.charAt(2)));
        typeEditBox(otac_04, Character.toString(otac.charAt(3)));
        typeEditBox(otac_05, Character.toString(otac.charAt(4)));
        clickElement(continue_button);
        driver.switchTo().defaultContent();
    }

    public void customerSendsPin(String pin) {
        waitForVisible(pin_01);
        typeEditBox(pin_01, Character.toString(pin.charAt(0)));
        typeEditBox(pin_02, Character.toString(pin.charAt(1)));
        typeEditBox(pin_03, Character.toString(pin.charAt(2)));
        typeEditBox(pin_04, Character.toString(pin.charAt(3)));
        clickElement(continue_button);
        driver.switchTo().defaultContent();
    }

    public void customerSendsBirthdate(int day, int month, int year) {
        waitForVisible(back_button);
        if (screenAppeared(dateOfBirthDay)) {
            typeEditBox(dateOfBirthDay, Integer.toString(day));
            typeEditBox(dateOfBirthMonth, Integer.toString(month));
            typeEditBox(dateOfBirthYear, Integer.toString(year));
            clickElement(continue_button);
        } else Log.info("No birthdate window appeared");
    }

    public void customerSendsFirstAndLastName(String firstname, String lastname) {
        waitForVisible(back_button);
        if (screenAppeared(firstName)) {
            typeEditBox(firstName, firstname);
            typeEditBox(lastName, lastname);
            clickElement(continue_button);
        } else Log.info("No name window appeared");
    }

    /**
     * method to verify agent group name.
     *
     * @param agentGroupName the expected String
     */
    public void verifyAgentGroupName(String agentGroupName) {
        waitForVisible(userInputField);
        typeEditBox(userInputField, "/chatinfo");
        implicitWaitAndSleep(10);
        clickElement(sendButton);
        WebElement agentGroupNameElement = itsDriver.findElements(By.cssSelector("[class*='styled__KeyValue-']")).get(38);
        waitForVisible(agentGroupNameElement);
        assertElementText(agentGroupNameElement, agentGroupName);
    }

    /**
     * method to switch DXIDM Iframe.
     */
    public void switchToIFrameAcceptCookieDXIDM() {
        waitForVisible(iframeAcceptCookiesDXIDM);
        driver.switchTo().frame(iframeAcceptCookiesDXIDM);
    }

    /**
     * method to wait until message with specific index be visible.
     *
     * @param counter the index of message
     */
    public void waitForTextWithIndexToBeVisible(int counter) {
        waitForVisibleTextByIndex(Integer.toString(counter));
    }

    /**
     * This method Check that this quick reply is appears on the Tobi chat
     *
     * @param quickReplyText text which we search for
     */
    public void quickRepliesContainText(String quickReplyText) {
        checkIfTextOfTheQuickReplyPresentInAList(quickRepliesElements, quickReplyText);
    }

    /**
     * This function for verifying the check icon for its relevant bar.
     *
     * @param barList  The list for bars names
     * @param iconList The list for Icons for its relevant bars
     */
    public void verifyInternetChecklistUI(List<String> barList, List<String> iconList) {
        try {
            waitForVisible(iconState);
        } catch (Exception e) {
            assertFail("FAIL: State icons Not appeared");
        }
        for (int i = 0; i < barList.size(); i++) {
            if (ErrorChecklistNames.get(i).getText().equalsIgnoreCase(barList.get(i))) {
                assertElementAttributeContainsText(ErrorChecklistIcons.get(i), iconList.get(i).toLowerCase(), "data-src");
            } else {
                assertFail("FAIL: Elements are not matched.");
            }
        }
    }

    /**
     * Selects the phone number from the dropdown list in Choose phone number screen in DXIDM,
     * if there were multiple numbers managed by the used account, and move into the next DXIDM screen.
     *
     * @param ctn The phone number to be used.
     */
    public void customerSelectDXIDM_CTN(String ctn) {
        waitForVisible(securityCodeScreenTitle);
        // check if user has to choose phone number before continuing and selects the phone number from the dropdown list
        if (continue_button.getAttribute("aria-disabled").equals("true")) {
            Select dropCtn = new Select(choosePhoneDrp);
            String lastFourDigits = ctn.substring(ctn.length() - 4);
            dropCtn.selectByVisibleText("XXXXXXXX" + lastFourDigits);
        }
        clickElement(continue_button);
    }

    /**
     * To use in negative scenarios, to force close DXIDM iframe.
     */
    public void customerForceCloseDXIDM() {
        driver.switchTo().defaultContent();
        waitForVisible(closeDXIDM_button);
        closeDXIDM_button.click();
    }

    /**
     * This function for checking Network in Area Through Network Status Checker (NSC).
     *
     * @param buttonText The Aria-label attribute for a button tag.
     */
    public void customerChecksNetworkInArea(String buttonText) {
        buttonsWithAriaLabel(buttonText).get(buttonsWithAriaLabel(buttonText).size() - 1).click();
    }

    /**
     * This function for waiting for visibility of a button then clicking on it. (used in NSC)
     *
     * @param buttonText The value attribute for a button tag.
     */
    public void customerWaitsAndClicksOnButton(String buttonText) {
        WebElement element = itsDriver.findElement(By.id("tobi-ui-root")).findElement(By.cssSelector("button[value*=\"" + buttonText + "\"]"));
        waitForVisible(element);
        element.click();
        ++Count;
    }

    /**
     * To be used in DSL check ONLY.
     * Verifies if the ctnType is correct in DSL check.
     *
     * @param ctnType payM or payG or Voxi.
     */
    public void verifyDSLcheckCTNtype(String ctnType) {
        if (ctnType.equalsIgnoreCase("bingo") || ctnType.equalsIgnoreCase("paym")) {
            verifyTobiResponsesContain("\"connectionType\":\"POSTPAY\"");
            if (ctnType.equalsIgnoreCase("bingo"))
                verifyTobiResponseAlsoContains("\"bingo\":true", "FAIL: Number isn't Bingo");
            else if (ctnType.equalsIgnoreCase("payM"))
                verifyTobiResponseAlsoContains("\"bingo\":false", "FAIL: Number is bingo");
        } else if (ctnType.equalsIgnoreCase("payG")) verifyTobiResponsesContain("\"connectionType\":\"PAYG\"");
    }

    /**
     * To be used in DXIDM check ONLY.
     * Evaluate and validate if the permissions of the account is correctly assigned in DXIDM check,
     * based on the combination of account role and subscription role/s.
     *
     * @param ctnType     payM or Bingo, currently doesn't support the other segments.
     * @param permissions owner, BillPayer, ServiceUser, AdminL0, AdminL1, AdminL2.
     */
    public void verifyPermissions(String ctnType, String permissions) {
        // set to default values of an owner
        String accountRole = "owner", subscriptionRole = "owner", accountType = "Consumer";
        if (permissions.equalsIgnoreCase("AdminL0") || permissions.equalsIgnoreCase("Admin L0") || permissions.equalsIgnoreCase("L0")) {
            accountType = "Small-Business";
        } else if (permissions.equalsIgnoreCase("AdminL1") || permissions.equalsIgnoreCase("Admin L1") || permissions.equalsIgnoreCase("L1")) {
            accountRole = "AdminL1";
        } else if (permissions.equalsIgnoreCase("AdminL2") || permissions.equalsIgnoreCase("Admin L2") || permissions.equalsIgnoreCase("L2")) {
            accountRole = "AdminL2";
        } else if (permissions.equalsIgnoreCase("BillPayer") || permissions.equalsIgnoreCase("Bill Payer")) {
            subscriptionRole = "BillPayer";
        } else if (permissions.equalsIgnoreCase("User") || permissions.equalsIgnoreCase("Service User") || permissions.equalsIgnoreCase("ServiceUser")) {
            subscriptionRole = "User";
        } else if (permissions.equalsIgnoreCase("BillPayer,User") || permissions.equalsIgnoreCase("User,BillPayer") || permissions.equalsIgnoreCase("User,Bill Payer") || permissions.equalsIgnoreCase("Bill Payer, User")) {
            subscriptionRole = "User,BillPayer";
        } else {
            assertFail("FAIL: Please enter a valid role. Valid roles are: owner, BillPayer, User, AdminL0, AdminL1, AdminL2");
        }
        verifyTobiResponsesContain("\"type\":\"" + accountType + "\"");
        verifyTobiResponseAlsoContains("\"roles\":\"" + accountRole + "\",\"parent_account_id\"", "FAIL: Account role '%s' isn't correct in the element : %s ", accountRole);
        if (ctnType.equalsIgnoreCase("paym"))
            verifyTobiResponseAlsoContains("\"type\":\"SIMO\",\"roles\":\"" + subscriptionRole, "FAIL: Subscription role '%s' isn't correct in the element : %s ", subscriptionRole);
        else if (ctnType.equalsIgnoreCase("bingo"))
            verifyTobiResponseAlsoContains("\"type\":\"HANDSET\",\"roles\":\"" + subscriptionRole, "FAIL: Subscription role '%s' isn't correct in the element : %s ", subscriptionRole);
    }

    /**
     * To be used in DXIDM check ONLY.
     * Verifies if the first name is correct in DXIDM check.
     *
     * @param firstname the account given first name.
     */
    public void verifyThatFirstNameIs(String firstname) {
        verifyTobiResponseAlsoContains("given_name\":\"" + firstname + "\"");
    }

    /**
     * To be used in DXIDM check ONLY.
     * Verifies if the username is correct in DXIDM check.
     *
     * @param username the account given username.
     */
    public void verifyThatUsernameIs(String username) {
        verifyTobiResponseAlsoContains("username\":\"" + username + "\"");
    }

    public void outOfPlanChargesEqualZero(boolean equalZero) {
        verifyTobiResponsesContain("billType\":\"Future bill\",\"billStatus\":\"pending\"");
        if (equalZero)
            verifyTobiResponseAlsoContains("totalOutOfPlanCharges\":{\"value\":\"0.00\"", "FAIL: Total Out of plan charges isn't equal to zero");
        else
            verifyTobiResponseAlsoDoesntContain("totalOutOfPlanCharges\":{\"value\":\"0.00\"", "FAIL: Total Out of plan charges is equal to zero");
    }

    public void verifyThatOneOfTheResponsesAppeared(List<String> tobiResponses) {
        try {
            ++Count;
            waitForTextWithIndexToBeVisible(Count);
        } catch (Exception e) {
            for (String tobiResponse : tobiResponses)
                assertFail(String.format("FAIL: Tobi new message '%s' with index '%s' did not display in time", tobiResponse, Count));
        }
        lastVerifiedTobiResponseLocator = checkIfAnyExpectedTextIsPresentInLastResponse(Count, tobiResponses);
    }

    public void verifyThatThisResponseAlsoContainsTheCorrespondingSentence(List<String> tobiResponses) {
        verifyThatThisResponseAlsoContainsTheCorrespondingSentence(lastVerifiedTobiResponseLocator, tobiResponses);
    }

    public void verifyBillInfoExist(List<String> billInfo) {
        for (String everyBillInfo : billInfo) {
            try {
                billDetailsCardText(everyBillInfo);
            } catch (Exception e) {
                assertFail(String.format("FAIL: Bill info '%s' doesn't exist in billing details card.", everyBillInfo));
            }
        }
    }

    public void openBillDetails() {
        billDetailsButton.click();
    }

    public void clickBackButton() {
        backButton.click();
    }

    public void quickRepliesContainText(List<String> quickRepliesText) {
        implicitWaitAndSleep(5);
        for (String quickReplyText : quickRepliesText)
            checkIfTextOfTheQuickReplyPresentInAList(quickRepliesElements, quickReplyText);
    }

    /**
     * Verifies that the buttons have appeared in the last Tobi response.
     *
     * @param buttonsText List of buttons text.
     */
    public void tobiReplyContainsButtons(List<String> buttonsText) {
        for (String buttonText : buttonsText) {
            if (buttonWithValueInCurrentResponse(buttonText) == null) {
                assertFail(String.format("No buttons found with such text: '%s'", buttonText));
                break;
            }
        }
    }

    /**
     * Single line OTP login. Handles the old and new flows.
     *
     * @param ctn the phone number.
     */
    public void loginOTP(String ctn) {
        loginOTP_start(ctn);
        customerSendsOtpAndVerifySecurityCompleted();
    }

    /**
     * Single line OTP login. Handles the old and new flows.
     *
     * @param ctn       the phone number.
     * @param firstname customers' first name.
     * @param lastname  customers' last name.
     * @param day       the day of birth of the costumer.
     * @param month     the month of birth of the costumer.
     * @param year      the year of birth of the costumer.
     */
    public void loginOTP(String ctn, String firstname, String lastname, int day, int month, int year) {
        loginOTP_start(ctn);
        customerSendsBirthdate(day, month, year);
        customerSendsFirstAndLastName(firstname, lastname);
        customerSendsOtpAndVerifySecurityCompleted();
    }

    private void loginOTP_start(String ctn) {
        String oldMessage = "For this security check, I'll need to take your phone number to send you a security code by text. I'll launch a secure pop-up for you to enter your number now.";
        String newMessage = "How would you like to complete security?";
        if (newflow) {
            verifyTobiResponsesContain(newMessage);
            customerClickOn("Receive a code to my phone");
            verifyTobiResponsesContain("Great, I'll launch a secure pop-up for you to enter your phone number now.");
        } else {
            verifyTobiResponsesContain(oldMessage);
        }
        switchToIFrameAcceptCookieDXIDM();
        customerSendsCTN(ctn);
    }

    private void customerSendsOtpAndVerifySecurityCompleted() {
        String otp;
        if (url.contains(System.getProperty("prodURL", props.getProperty("PRODUCTION.URL"))) || url.contains("staging"))
            otp = "4U7F1";
        else otp = "12345";
        customerSendsOtac(otp);
        verifyTobiResponsesContain("Thanks, that's the security part completed.");
    }

    /**
     * method to choose  specific plan card.
     *
     * @param planCardNumber the card number
     */
    public void choosePlanCard(ChooseCard type ,int planCardNumber) {
        switch (type) {
            case Plan -> {
                itsWait.until(ExpectedConditions.elementToBeClickable(choosePlanList().get(planCardNumber - 1)));
                clickUsingJavaScript(choosePlanList().get(planCardNumber - 1));
            }
            case Card -> {
                itsWait.until(ExpectedConditions.elementToBeClickable(AddPlanList().get(planCardNumber - 1)));
                clickUsingJavaScript(AddPlanList().get(planCardNumber - 1));
            }
            case AddtoPlan -> {
                itsWait.until(ExpectedConditions.elementToBeClickable(AddToPlan().get(planCardNumber - 1)));
                clickUsingJavaScript(AddToPlan().get(planCardNumber - 1));
            }
            default -> System.out.println("No Cards found");
        }

        Count++;
    }



    /**
     * method to click on new message button that appear when tobi message very long.
     */
    public void clickOnNewMessage() {
        waitForVisible(newMessageButton);
        newMessageButton.click();
    }
    public void clickOnBasket() {
        waitForVisible(basket);
        clickElement(basket);
    }

    /**
     * method to switch to the second tab and check it's title and text on it.
     *
     * @param link the link of new tab that need to verify it
     */

    public void verifyLinkOPendInNewTab(String link) {
        switchToSecondTab();
        implicitWaitAndSleep(10);
        try {
            waitForVisible(acceptCookiesFrame);
            clickElement(acceptCookiesButton);
        } catch (Exception e) {
            System.out.println("Cookies not displayed");
        }
        assertEquals(link, itsDriver.getCurrentUrl());
    }

    /**
     * method to back to parent tab.
     */
    public void backToParentTab() {
        backToParentTabWindow();
    }

    /**
     * method to check element contains some text
     *
     * @param element element that want to check it has the text
     * @param text    specific text that want to check it in specific element
     */
    public void verifyPageContainsText(WebElement element, String text) {
        assertTextIsVisible(element, "Element Not appear in the page", text);
    }

    /**
     * verify card number list.
     *
     * @param numberOfPlanCards number of cards
     */
    public void verifyNumberOfPlanCard(String numberOfPlanCards) {
        assertEquals(Integer.parseInt(numberOfPlanCards), choosePlanList().size());
    }

    public void skipDXIDM() {
        verifyTobiResponsesContain("How would you like to complete security?");
        customerClickOnInLastResponse("Log in with");
        verifyTobiResponsesContain("Great, I'll launch a secure pop-up for you");
        customerForceCloseDXIDM();
        verifyTobiResponsesContain("It looks like you closed the window before we were able to complete security.");
        customerSays("no");
        verifyTobiResponsesContain("No problem, I can still check if an agent is available.");
    }
}