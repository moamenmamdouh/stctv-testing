package com.cucmber.stepdefinition.newUI;

import com.cucmber.core.WebDriverActions;
import com.cucmber.core.helper.ScumberException;
import com.cucmber.page.resetChat.ResetChatHelper;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;

import java.util.logging.Logger;

public class ResetChatSD {
    private final static Logger Log = Logger.getLogger(ResetChatSD.class.getName());

    private ResetChatHelper reset_chat_helper;
    private WebDriver itsDriver;

    public ResetChatSD() {
        Log.info("Constructor: Close_Chat_sD");
    }

    @Before
    public void before(final Scenario scenario)
            throws ScumberException {
        itsDriver = WebDriverActions.openBrowser(scenario);
        reset_chat_helper = new ResetChatHelper(itsDriver);
    }

    @When("customer click on Three Dot CTA")
    public void customer_click_on_Three_Dot_CTA() {
        reset_chat_helper.Click_on_Three_Dot_CTA();
    }

    @And("customer click on reset chat CTA")
    public void customerClickOnResetChatCTA() {
        reset_chat_helper.Click_on_Reset_Chat_CTA();
    }

    @Then("validate the chat reset not contain")
    public void validateTheChatResetNotContain(String text) {
        reset_chat_helper.validate_text_not_present_in_list(text);
    }
}
