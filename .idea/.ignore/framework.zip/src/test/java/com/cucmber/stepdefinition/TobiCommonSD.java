package com.cucmber.stepdefinition;

import api.enums.ChooseCard;
import com.cucmber.core.WebDriverActions;
import com.cucmber.core.helper.ScumberException;
import com.cucmber.page.agentWebsite.AgentHelper;
import com.cucmber.page.common.CommonHelper;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;


public class TobiCommonSD {
    private final static Logger Log = Logger.getLogger(TobiCommonSD.class.getName());

    private CommonHelper commonHelper;
    private AgentHelper agentHelper;
    private WebDriver itsDriver;

    public TobiCommonSD() {
        Log.info("Constructor: CommonSD");
    }

    @Before
    public void before(final Scenario scenario) throws ScumberException {
        itsDriver = WebDriverActions.openBrowser(scenario);
        commonHelper = new CommonHelper(itsDriver);
        agentHelper = new AgentHelper(itsDriver);
    }


    @Given("Accept all cookies")
    public void acceptCookies() {
        commonHelper.acceptCookies();
    }

    /**
     * To be used in scenario outlines only,
     * just for printing the role to describe the used customer role for the outline examples results readers.
     *
     * @param role the role of the used CTN.
     */
    @Given("Customer role is {string}")
    public void customerAskTobiWithRole(String role) {
        System.out.println("Customer role is: " + role);
    }

    @Given("Customer asks Tobi {string}")
    @Given("Customer says {string}")
    @Given("Customer enters {string}")
    public void customerAskTobi(String customerSays) {
        commonHelper.customerSays(customerSays);
    }

    @Given("Wait for assistant launch")
    public void assistantLaunch() {
        commonHelper.chatDisplayed();
    }

    @Given("Verify hyperlink {string}")
    public void hyperlink(String hyperlink) {
        commonHelper.hyperlinkCheck(hyperlink);
    }

    /**
     * Check if that hyperlink with that linkText exists in any of Tobi responses.
     *
     * @param hyperlink The hyperlink to be found.
     * @param linkText  The link text of the hyperlink.
     */
    @Given("Verify hyperlink {string} and its link text is {string}")
    public void hyperlink(String hyperlink, String linkText) {
        commonHelper.hyperlinkCheck(hyperlink, linkText);
    }

    @Then("Verify Tobi responses contain")
    public void tobiResponseContain(String tobiSays) {
        commonHelper.verifyTobiResponsesContain(tobiSays);
    }

    @Then("Verify Tobi responses contain for cards")
    public void tobiResponseContainForCards(String tobiSays) {
        commonHelper.verifyTobiResponsesContainForCards(tobiSays);
    }

    /**
     * Check if the last response message that was found by "Verify Tobi Responses Contain" also contains that text.
     *
     * @param tobiResponse The text to be found
     */
    @Then("Verify that this response also contains")
    public void tobiResponseAlsoContains(String tobiResponse) {
        commonHelper.verifyTobiResponseAlsoContains(tobiResponse);
    }

    /**
     * Check if the last response message that was found by "Verify Tobi Responses Contain" also contains that hyperlink with the linkText.
     *
     * @param hyperlink The hyperlink to be found.
     * @param linkText  The link text of the hyperlink.
     */
    @And("Verify that this response contains hyperlink {string} and its link text is {string}")
    public void tobiResponseContainsHyperlink(String hyperlink, String linkText) {
        commonHelper.verifyTobiResponseContainsHyperlink(hyperlink, linkText);
    }

    @Then("Customer clicks on {string}")
    public void customerClickOn(String tobiSays) {
        commonHelper.customerClickOn(tobiSays);
    }

    @And("Customer clicks on hyperlink {string}")
    public void customerClicksOnHyperlinkString(String hyperlink) {
        commonHelper.customerClicksOnHyperlinkString(hyperlink);
    }

    /**
     * To use in negative scenarios, to force close DXIDM iframe.
     */
    @When("Customer force close DXIDM")
    public void customerForceCloseDXIDM() {
        commonHelper.customerForceCloseDXIDM();
    }

    /**
     * Enters the phone number into the phone number field in the phone number screen in DXIDM.
     *
     * @param ctn The phone number
     */
    @When("Customer sends CTN {string}")
    public void customerSendsCTN(String ctn) {
        commonHelper.customerSendsCTN(ctn);
    }

    @When("Customer fills OTP")
    public void customerSendsOtac() {
        String otac = commonHelper.getOtac();
        commonHelper.customerSendsOtac(otac);
    }

    /**
     * Enters the birthdate of the user in the DXIDM, if the screen appeared.
     *
     * @param day   The day of birth.
     * @param month The month of birth.
     * @param year  The year of birth.
     */
    @When("Customer enters birthdate day {int}, month {int} and year {int}")
    public void customerEntersBirthdate(int day, int month, int year) {
        commonHelper.customerSendsBirthdate(day, month, year);
    }

    /**
     * Enters the name of the user in the DXIDM, if the screen appeared.
     *
     * @param firstname The first name of the user.
     * @param lastname  The last name of the user.
     */
    @When("Customer enters first name {string} and last name {string}")
    public void customerEntersFirstAndLastName(String firstname, String lastname) {
        commonHelper.customerSendsFirstAndLastName(firstname, lastname);
    }

    /**
     * Selects the phone number from the dropdown list in Choose phone number screen in DXIDM,
     * if there were multiple numbers managed by the used account, and move into the next DXIDM screen.
     *
     * @param ctn The phone number to be used.
     */
    @When("Customer select CTN {string} from DXIDM dropdown menu")
    public void customerChooseCTN(String ctn) {
        commonHelper.customerSelectDXIDM_CTN(ctn);
    }

    @Then("Verify agent group name {string}")
    public void verifyAgentGroupName(String agentGroupName) {
        commonHelper.verifyAgentGroupName(agentGroupName);
    }

    @When("Accept DXIDM cookies")
    public void customerClickOnAcceptCookiesDXIDM() {
        commonHelper.switchToIFrameAcceptCookieDXIDM();
    }

    /**
     * Login DXIDM with username and password and switch focus from DXIDM iframe to the chat after closing the DXIDM.
     * To be used in LOA1 and LOA2 cases only.
     *
     * @param username username to sign in with
     * @param password password to sign in with
     */
    @And("Customer login DXIDM with username {string} and password {string}")
    public void customerLoginDXIDMWithUserNameAndPassword(String username, String password) {
        // login with LOA2 username and password option
        commonHelper.DXIDMLoginLAO2usernamePassword(username, password);
    }

    /**
     * Login DXIDM with username and password, without switching focus away from DXIDM iframe.
     * To be used in LOA3 cases.
     *
     * @param username username to sign in with.
     * @param password password to sign in with.
     */
    @And("Customer enters username {string} and password {string}")
    public void customerEntersUsernameAndPassword(String username, String password) {
        commonHelper.DXIDMLoginUsernamePassword(username, password);
    }

    /**
     * @param username    username of the agent
     * @param agentStatus status of the agent
     */
    @Given("Agent username {string} and status {string}")
    public void agentUsernameAndStatus(String username, String agentStatus) {
        agentHelper.agentUsernameAndStatus(username, agentStatus);
    }

    @And("Customer waits for {int} sec")
    public void customerWaitTimeMin(int time) {
        commonHelper.implicitWaitAndSleep(time);
    }

    @But("Verify Tobi responses don't contain")
    public void verifyTobiResponsesNotContain(String tobiSays) {
        commonHelper.verifyTobiResponsesNotContain(tobiSays);
    }

    @And("Customer sends OTAC {string}")
    public void customerSendsOTAC(String otac) {
        commonHelper.customerSendsOtac(otac);
    }

    /**
     * Enters the user PIN in the PIN screen in DXIDM if user chose to login with PIN.
     *
     * @param pin The user pin.
     */
    @And("Customer sends PIN {string}")
    public void customerSendsPIN(String pin) {
        commonHelper.customerSendsPin(pin);
    }

    @And("Verify Tobi quick replies contain {string}")
    public void verifyTobiQuickRepliesContain(String quickReplyText) {
        commonHelper.quickRepliesContainText(quickReplyText);
    }

    @Then("Verify Mobile connectivity error checklist [Bars, Status]")
    @Then("Verify Home Broadband connectivity error checklist [Bars, Status]")
    public void verifyErrorChecklist(DataTable dt) {
        List<List<String>> rows = dt.cells();

        List<String> listName = new ArrayList<>();
        List<String> listIcon = new ArrayList<>();

        for (List<String> row : rows) {
            listIcon.add(row.get(1));
            listName.add(row.get(0));
        }

        commonHelper.verifyInternetChecklistUI(listName, listIcon);
    }

    @When("Customer jumps to {string}")
    public void customerChecksNetworkInArea(String buttonText) {
        commonHelper.customerChecksNetworkInArea(buttonText);
    }

    @And("Customer waits and clicks on {string}")
    public void customerWaitsAndClicksOnButton(String buttonText) {
        commonHelper.customerWaitsAndClicksOnButton(buttonText);
    }

    /**
     * To be used in DXIDM check ONLY.
     * Evaluate and validate if the permissions of the account is correctly assigned in DXIDM check,
     * based on the combination of account role and subscription role/s.
     *
     * @param ctnType     payM or Bingo, currently doesn't support the other segments.
     * @param permissions owner, BillPayer, ServiceUser, AdminL0, AdminL1, AdminL2.
     */
    @And("verify that ctn type is {string} and permissions are of {string} role")
    public void verifyPermissions(String ctnType, String permissions) {
        commonHelper.verifyPermissions(ctnType, permissions);
    }

    /**
     * To be used in DXIDM check ONLY.
     * Verifies if the first name is correct in DXIDM check.
     *
     * @param firstname the account given first name.
     */
    @And("verify that first name is {string}")
    public void verifyThatFirstNameIs(String firstname) {
        commonHelper.verifyThatFirstNameIs(firstname);
    }

    /**
     * To be used in DXIDM check ONLY.
     * Verifies if the username is correct in DXIDM check.
     *
     * @param username the account given username.
     */
    @And("verify that username is {string}")
    public void verifyThatUsernameIs(String username) {
        commonHelper.verifyThatUsernameIs(username);
    }

    /**
     * To be used in DSL check ONLY.
     * Verifies if the ctnType is correct in DSL check.
     *
     * @param ctnType payM or payG or Voxi.
     */
    @And("verify that ctn is {string}")
    public void verifyThatCtnIs(String ctnType) {
        commonHelper.verifyDSLcheckCTNtype(ctnType);
    }

    @When("customer open the bill details")
    public void customerOpenTheBillDetails() {
        commonHelper.openBillDetails();
    }

    @When("customer click the back button")
    public void customerClickTheBackButton() {
        commonHelper.clickBackButton();
    }

    @Then("verify bill details contain")
    public void verifyBillsDetailsContain(List<String> billInfo) {
        commonHelper.verifyBillInfoExist(billInfo);
    }

    @And("Verify Tobi quick replies contain")
    public void verifyTobiQuickRepliesContain(List<String> quickRepliesText) {
        commonHelper.quickRepliesContainText(quickRepliesText);
    }

    /**
     * Verifies that the buttons have appeared in the last Tobi response.
     *
     * @param buttonsText List of buttons text.
     */
    @And("verify Tobi reply contains buttons")
    public void verifyTobiReplyContainsButtons(List<String> buttonsText) {
        commonHelper.tobiReplyContainsButtons(buttonsText);
    }

    @And("verify that total out of plan charges equal to zero")
    public void outOfPlanChargesEqualZero() {
        commonHelper.outOfPlanChargesEqualZero(true);
    }

    @And("verify that total out of plan charges more than zero")
    public void outOfPlanChargesMoreThanZero() {
        commonHelper.outOfPlanChargesEqualZero(false);
    }

    @Then("verify that one of the following responses appeared:")
    public void verifyThatOneOfTheResponsesAppeared(List<String> tobiResponses) {
        commonHelper.verifyThatOneOfTheResponsesAppeared(tobiResponses);
    }

    @And("verify that this response also contains the corresponding sentence:")
    public void verifyThatThisResponseAlsoContainsTheCorrespondingSentence(List<String> tobiResponses) {
        commonHelper.verifyThatThisResponseAlsoContainsTheCorrespondingSentence(tobiResponses);
    }

    @Then("login using OTP with phone number {string}")
    public void loginUsingOTPWithPhoneNumber(String ctn) {
        commonHelper.loginOTP(ctn);
    }

    @Then("login using OTP with phone number {string}, first name {string}, last name {string}, birthdate day {int}, month {int} and year {int}")
    public void loginUsingOTPWithPhoneNumber(String ctn, String firstname, String lastname, int day, int month, int year) {
        commonHelper.loginOTP(ctn, firstname, lastname, day, month, year);
    }

    /**
     * to click on specific plan card.
     *
     * @param number the card number that want to click on it.
     */
    @When("Customer choose {string} number {int}")
    public void customerChooseNumber(String type, int number)  {
        commonHelper.choosePlanCard(ChooseCard.valueOf(type),number);
    }

    /**
     * to click on new message button when tobi response message very long
     */
    @When("Customer click on new message")
    public void customerClickOnNewMessage() {
        commonHelper.clickOnNewMessage();
    }
    @When("Customer clicks on Basket")
    public void customerClickOnBasket() {
        commonHelper.clickOnBasket();
    }

    /**
     * to verify the link opened on new tab.
     *
     * @param newLink the link of new tab
     */
    @And("verify link open in new tab {string}")
    public void verifyLinkOpenInNewTab(String newLink) {
        commonHelper.verifyLinkOPendInNewTab(newLink);
        commonHelper.backToParentTab();
    }

    /**
     * to verify the link opened on new tab and the new page has specific text.
     *
     * @param newLink          the link of new tab
     * @param textInTheNewPage the specific text in the new page
     */
    @And("Verify link open in new tab {string} and has text {string}")
    public void verifyLinkOpenInNewTabAndHasText(String newLink, String textInTheNewPage) {
        commonHelper.verifyLinkOPendInNewTab(newLink);
        commonHelper.verifyPageContainsText(commonHelper.reviewYourBasketTxt, textInTheNewPage);
        commonHelper.backToParentTab();
    }

    /**
     * method to verify number of plan cards.
     *
     * @param numberOfPlanCard number of plan cards
     */
    @And("Verify card number has {string} cards")
    public void verifyCardNumberHasCards(String numberOfPlanCard) {
        customerWaitTimeMin(30);
        commonHelper.verifyNumberOfPlanCard(numberOfPlanCard);
    }

    @Then("Verify Tobi responses contain {string}")
    public void verifyTobiResponsesContain(String tobiSays) {
        commonHelper.verifyTobiResponsesContain(tobiSays);
    }

    @And("Verify card number for twenty four months has {string} cards")
    public void verifyCardNumberForTwentyFourMonthsHasCards(String numberOfPlanCard) {
        commonHelper.verifyNumberOfPlanCard(numberOfPlanCard);
        if (commonHelper.choosePlanList().size() >= 3) {
            customerWaitTimeMin(10);
            System.out.println("number of plans : " + commonHelper.choosePlanList().size());
        } else {
            Log.info("There are only three plans. Appeared");
        }
    }

    @And("login using username {string}")
    public void customerLoginDXIDMWithUsername(String username) {
        commonHelper.DXIDMLoginUsername(username);
    }

    @And("skip and close DXIDM login window")
    public void skipDXIDM() {
        commonHelper.skipDXIDM();
    }

}
