package com.cucmber.page.agentWebsite;

import org.openqa.selenium.WebDriver;

import java.util.Properties;

import static com.cucmber.core.helper.PropertiesLoader.readPropertyFile;

public class AgentHelper extends AgentLoginPO {

    private final Properties props = readPropertyFile("config/config.properties");

    public AgentHelper(WebDriver driver) {
        super(driver);
    }

    /**
     * method to open agent website.
     */
    public void getAgentWebsite() {
        Properties props = readPropertyFile("config/config.properties");
        openNewTabWindow();
        itsDriver.navigate().to(System.getProperty("url", props.getProperty("agent.url")));
    }

    /**
     * method to login to agent website.
     *
     * @param UserName the username for agent website
     * @param Password the password for agent website
     */
    public void LoginToAgent(String UserName, String Password) {
        getAgentWebsite();
        AgentUsername_txt.sendKeys(UserName);
        AgentPassword_txt.sendKeys(Password);
        SubmitLogin_btn.click();
    }

    /**
     * method to select status of the agent.
     *
     * @param StatusType the status of the agent
     */
    public void SelectAgentStatus(String StatusType) {
        waitForVisible(DropDownMenuStatus);
        DropDownMenuStatus.click();
        if (StatusType.equals("Available")) {
            AgentAvailableStatus.click();
        } else if (StatusType.equals("Busy")) {
            AgentBusyStatus.click();
        }
    }

    /**
     * @param agentUserName username of the agent
     * @param agentStatus   Status of the agent(Available, Busy, ...)
     */
    public void agentUsernameAndStatus(String agentUserName, String agentStatus) {
        String url = System.getProperty("url", props.getProperty("application.url"));
        if (!(url.contains(System.getProperty("prodURL", props.getProperty("PRODUCTION.URL"))))) {
            LoginToAgent(agentUserName, System.getProperty("password", props.getProperty("agent_password")));
            SelectAgentStatus(agentStatus);
            backToParentTabWindow();
        } else {
            System.out.println("Production Agent");
        }
    }
}
