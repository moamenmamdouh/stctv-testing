package com.cucmber.page.minimizeChat;

import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.Assertions.assertFalse;

public class MinimizeChatHelper extends MinimizeChatpo {

    public MinimizeChatHelper(WebDriver driver) {
        super(driver);
    }

    public void minimize_chat() {
        minimize_CTA.click();
    }

    public void validate_chat_minimized() {
        assertFalse(minimize_CTA.isDisplayed());
    }

    public void open_Chat_icon() {
        ChatToggle.click();
    }
}