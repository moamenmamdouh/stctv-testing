package com.cucmber.core;

import com.cucmber.core.helper.ScumberException;
import io.cucumber.java.Scenario;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Options;
import org.openqa.selenium.WebDriverException;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Logger;

import static com.cucmber.core.helper.PropertiesLoader.readPropertyFile;

public class WebDriverActions {
    private static final Logger Log = Logger.getLogger(WebDriverActions.class.getName());

    private static final Map<String, WebDriver> DRIVER_CACHE = new HashMap<>();
    private static final Object MONITOR = new Object();

    private WebDriverActions() {
        // Should not be instantiated directly
    }

    public static WebDriver openBrowser(final Scenario scenario)
            throws ScumberException {
        Log.info("Called openBrowser Name: " + scenario.getName() + " ID: " + scenario.getId());

        final String id = scenario.getId();

        synchronized (MONITOR) {
            final WebDriver driver = DRIVER_CACHE.get(id);

            if (driver != null) {
                // Driver already exists, thus lets reuse it.
                return driver;
            }

            final WebDriver newDriver = WebDriverFactory.createWebDriver();

            initDriver(newDriver);

            DRIVER_CACHE.put(id, newDriver);

            return newDriver;
        }
    }

    private static void freeDriver(final String id) {
        synchronized (MONITOR) {
            final WebDriver driver = DRIVER_CACHE.remove(id);

            assert driver != null : "Expected to have a driver to free: " + id;
            if (driver != null) {
                driver.quit();
            }
        }
    }

    private static void initDriver(final WebDriver driver) {
        final String userDir = System.getProperty("user.dir");

        Log.info("Initializing new driver for user: " + userDir);

        final Options manage = driver.manage();

        manage.deleteAllCookies();
        manage.timeouts().implicitlyWait(Duration.ofSeconds(30));
        manage.window().maximize();
    }

    public static void closeBrowser(final Scenario scenario, final WebDriver driver) {
        Log.info("Called closeBrowser Name: " + scenario.getName() + " ID: " + scenario.getId());

        try {
            driver.manage().deleteAllCookies();
            driver.quit();
        } finally {
            freeDriver(scenario.getId());
        }
    }

    public static void embedScreenShot(final Scenario scenario, final WebDriver driver) {
        Log.info("Called embedScreenShot Name: " + scenario.getName() + " ID: " + scenario.getId());

        try {
            Properties props = readPropertyFile("config/config.properties");
            scenario.log("INFO: The current URL is: " + driver.getCurrentUrl());
            final byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
            scenario.attach(screenshot, "image/png", "embedScreenShot");
        } catch (final WebDriverException somePlatformsDontSupportScreenshots) {
            Log.warning(somePlatformsDontSupportScreenshots.getMessage());
        }
    }
}
