package com.cucmber.stepdefinition.newUI;

import com.cucmber.core.WebDriverActions;
import com.cucmber.core.helper.ScumberException;
import com.cucmber.page.tobiIcons.TOBiIconsHelper;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebDriver;

import java.util.logging.Logger;

public class TOBiIconsSD {

    private final static Logger Log = Logger.getLogger(CloseChatSD.class.getName());

    private TOBiIconsHelper tobiIconsHelper;
    private WebDriver itsDriver;

    public TOBiIconsSD() {
        Log.info("Constructor: TOBiIconsSD");
    }

    @Before
    public void before(final Scenario scenario)
            throws ScumberException {
        itsDriver = WebDriverActions.openBrowser(scenario);
        tobiIconsHelper = new TOBiIconsHelper(itsDriver);
    }

    /**
     * This a SD for checking the icon/avatar for TOBi
     *
     * @param tobiIcon could be "Tobi" for Tobi default icon OR "Hearts" for valentines day
     */
    @Then("Verify TOBi icon displayed as the default {string}")
    @Then("Verify Tobi Icon displayed with {string} for Valentines day")
    public void verifyAppearanceOfTOBiIcon(String tobiIcon) {
        tobiIconsHelper.verifyTobiIconDisplay(tobiIcon);
    }
}
