package com.cucmber.core.utils;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Logger;

import static com.cucmber.core.helper.PropertiesLoader.readPropertyFile;

public abstract class WebElementHelperMethods extends WebElementCheck {
    private final static Logger Log = Logger.getLogger(WebElementHelperMethods.class.getName());
    private final Actions action = new Actions(itsDriver);
    private final String browser;

    protected WebElementHelperMethods(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        final Properties browserProps = readPropertyFile("config/browser.properties");
        browser = System.getProperty("browser", browserProps.getProperty("browser"));
    }

    /**
     * This method will to move to element using the linktext attribute
     *
     * @param linkText
     */
    protected void moveToElementByLinkText(final String linkText) {
        final WebElement we = itsWait.until(ExpectedConditions.elementToBeClickable(By.linkText(linkText)));
        final String message = String.format("FAIL : Element with linktext '%s'", linkText);

        assertCheckIfNotNull(message, we);
        hoverOverElement(we);
    }

    /**
     * Hovers over the specified element
     *
     * @param we - webelement
     */
    protected void hoverOverElement(final WebElement we) {
        final String message = String.format("FAIL : Element with these details is NULL : '%s'", we);
        assertCheckIfNotNull(message, we);
        action.moveToElement(we).build().perform();
    }

    /**
     * This method will give the handle of the window
     *
     * @param title - title of the window
     */
    protected WebDriver getHandleToWindow(final String title) {
        WebDriver popup = null;
        final Set<String> windowIterator = itsDriver.getWindowHandles();
        Log.info("Total no of windows: " + windowIterator.size());

        for (final String window : windowIterator) {
            final String windowHandle = window;
            popup = itsDriver.switchTo().window(windowHandle);
            Log.info("Window Title: " + popup.getTitle() + " URL: " + popup.getCurrentUrl());

            if (popup.getTitle().contains(title)) {
                Log.info("Selected Window Title : " + popup.getTitle());
                return popup;
            }
        }
        final String popupTitle = popup != null ? popup.getTitle() : "<<Missing_Popup>>";
        Log.info("Window Title: " + popupTitle);
        return popup;
    }

    /**
     * This method will find the parent of an element
     *
     * @param element - webelement
     * @param level   - level
     */
    protected WebElement findParentElement(final WebElement element, final int level) {
        WebElement localElement = element;
        for (int i = 0; i < level; i++) {
            localElement = localElement.findElement(By.xpath(".."));
        }
        return localElement;
    }

    /**
     * This method will take the xpath replace target string with replacement, find the element and then click on it
     *
     * @param xpath  - xpath of webelement
     * @param target - value that needs to be replaced from xpath
     */
    protected void clickOnElementAfterReplaceValueFromXpath(
            final String xpath,
            final String target,
            final String relacement) {
        clickOnElementFromXpath(xpath.replace(target, relacement));
    }

    /**
     * This method will click on the element when the given text matches
     *
     * @param listOfElements - list of Elements
     * @param textToCheck    - value that needs to be replaced from xpath
     */
    protected void clickOnElementWhenTextMatches(final List<WebElement> listOfElements, final String textToCheck) {
        boolean found = false;
        for (final WebElement element : listOfElements) {
            if (element.getText().trim().contains(textToCheck)) {
                element.click();
                found = true;
                break;
            }
        }
        if (!found) {
            assertFail(String.format("FAIL : '%s' Button is not present ", textToCheck));
        }
    }

    /**
     * This method is to click clear and then populate the provided string in an element
     *
     * @param element        - webelement
     * @param textToPopulate - value that needs to be replaced from xpath
     */
    protected void clickClearSendkeys(final WebElement element, final String textToPopulate) {
        waitUntilElementIsClickable(element);
        waitForVisible(element);
        element.clear();
        element.sendKeys(textToPopulate);
    }

    /**
     * This method clicks on the element when he given xpath
     *
     * @param xpath - xpath
     */
    protected void clickOnElementFromXpath(final String xpath) {
        itsDriver.findElement(By.xpath(xpath)).click();
    }

    /**
     * This method will take the xpath replace target string with replacement, find the element and then return the element
     *
     * @param xpath       - xpath of webelement
     * @param target      - value that needs to be replaced from xpath
     * @param replacement - this value will be replaced by teh target in the xpath
     */
    protected WebElement getElementAfterReplaceValueFromXpath(
            final String xpath,
            final String target,
            final String replacement)
            throws NoSuchElementException {
        return itsDriver.findElement(By.xpath(xpath.replace(target, replacement)));
    }

    /**
     * This method will click on webelement using javascript
     *
     * @param element - webelement
     */
    protected void clickUsingJavaScript(final WebElement element) {
        try {
            final JavascriptExecutor js = (JavascriptExecutor) getDriver();
            js.executeScript("arguments[0].click();", element);
        } catch (final Exception exception) {
            assertFail("Unable to click on element " + exception.getStackTrace());
        }
    }

    /**
     * Type text value in textbox element
     *
     * @param editBox
     * @param valueToType
     */
    protected void typeEditBox(final WebElement editBox, final String valueToType) {
        waitForVisible(editBox);
        editBox.clear();
        editBox.sendKeys(valueToType);
    }

    /**
     * Select radio button for given element
     *
     * @param rdoElement
     * @throws Exception
     */
    protected void selectRadioButton(final WebElement rdoElement) {
        waitForVisible(rdoElement);
        if (!rdoElement.isSelected()) {
            rdoElement.click();
        }
    }

    /**
     * Select list option by visible option text in a drop down list
     *
     * @param optionText
     */
    protected void selectListByVisibleText(final WebElement listElement, final String optionText) {
        waitForVisible(listElement);
        final Select selectList = new Select(listElement);
        Log.info("Select list option: " + optionText);
        selectList.selectByVisibleText(optionText);
    }

    /**
     * Clicks on WebElement
     *
     * @param button Button element to click
     */
    protected void clickElement(final WebElement button) {
        waitForVisible(button);
        switch (browser.toLowerCase()) {
            case "chrome" -> button.click();
            case "firefox" -> ((JavascriptExecutor) itsDriver).executeScript("arguments[0].click();", button);
        }
    }

    /**
     * Set "value" attribute of element with attribute "name"
     *
     * @param name
     * @param value
     */
    protected void setValue(final String name, final String value) {
        ((JavascriptExecutor) itsDriver).executeScript("document.getElementsByName('" + name
                + "')[0].setAttribute('value', '" + value + "')");
    }

    /**
     * Get "value" attribute of an element
     *
     * @param webElement
     * @return
     */
    protected String getAttributeValue(final WebElement webElement) {
        return webElement.getAttribute("value");
    }

    /**
     * Wait for alert and click "Accept" if flag is true, otherwise simply close it.
     *
     * @param isAccept
     */
    protected void waitAlertAndClose(final boolean isAccept) {
        new WebDriverWait(itsDriver, Duration.ofSeconds(WAIT_TIMEOUT_DEFAULT)).until(ExpectedConditions.alertIsPresent());
        final Alert alert = itsDriver.switchTo().alert();
        if (isAccept) {
            alert.accept();
        } else {
            alert.dismiss();
        }
    }

    /**
     * Scroll to an element
     *
     * @param webElement The web element to scroll to
     */
    protected void scrollToElement(final WebElement webElement) {
        new Actions(itsDriver)
                .scrollToElement(webElement)
                .perform();
    }

    /**
     * method to open new tab window.
     */
    protected void openNewTabWindow() {
        ((JavascriptExecutor) itsDriver).executeScript("window.open()");
        ArrayList<String> tabs = new ArrayList<String>(itsDriver.getWindowHandles());
        itsDriver.switchTo().window(tabs.get(tabs.size() - 1));
    }

    /**
     * method to back to the parent tab window.
     */
    protected void backToParentTabWindow() {
        ArrayList<String> tabs = new ArrayList<String>(itsDriver.getWindowHandles());
        itsDriver.switchTo().window(tabs.get(0));
    }

    /**
     * method to switch to second tab in same window.
     */
    protected void switchToSecondTab() {
        ArrayList<String> tabs = new ArrayList<String>(itsDriver.getWindowHandles());
        itsDriver.switchTo().window(tabs.get(1));
    }
}
