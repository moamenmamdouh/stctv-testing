package com.cucmber.core;

import com.cucmber.core.helper.ScumberException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.*;

import java.io.File;
import java.util.Properties;
import java.util.logging.Logger;

import static com.cucmber.core.helper.PropertiesLoader.readPropertyFile;

public final class WebDriverFactory {
    private final static Logger Log = Logger.getLogger(WebDriverFactory.class.getName());

    private WebDriverFactory() {
        // Should not be invoked directly.
    }

    public static WebDriver createWebDriver() throws ScumberException {
        final Properties configProps = readPropertyFile("config/config.properties");
        final Properties browserProps = readPropertyFile("config/browser.properties");
        final String browser = System.getProperty("browser", browserProps.getProperty("browser"));
        final String OS = (System.getProperty("os.name")).toUpperCase();
        final boolean localDriver = Boolean.parseBoolean(configProps.getProperty("local_driver"));
        final boolean devTools = Boolean.parseBoolean(browserProps.getProperty("dev.tools"));
        final boolean browserProfile = Boolean.parseBoolean(browserProps.getProperty("vois.profile"));
        return createWebDriver(browser, OS, localDriver, devTools, browserProfile);
    }

    public static WebDriver createWebDriver(final String browser, final String OS, final boolean localDriver, final boolean devTools, final boolean browserProfile) throws ScumberException {
        Log.info("Creating browser instance: " + browser);
        switch (browser.toLowerCase()) {
            case "chrome" -> {
                return createChromeWebDriver(OS, localDriver, devTools);
            }
            case "firefox" -> {
                return createFireFoxWebDriver(OS, localDriver, devTools, browserProfile);
            }
        }

        throw new ScumberException("Unknown browser type: " + browser);
    }

    private static WebDriver createFireFoxWebDriver(final String OS, final boolean localDriver, final boolean devTools, final boolean browserProfile) {
        FirefoxOptions firefoxOptions = new FirefoxOptions();
        firefoxOptions.addArguments("--no-sandbox");
        firefoxOptions.addArguments("--disable-dev-shm-usage"); // overcome limited resource problems
        firefoxOptions.addArguments("--test-type");
        firefoxOptions.addArguments("--disable-dev-shm-usage");
        firefoxOptions.addArguments("--window-size=1920,1080");
        firefoxOptions.addArguments("--disable-infobars"); // disabling infobars
        firefoxOptions.addArguments("--disable-extensions"); // disabling extensions
        firefoxOptions.addArguments("--disable-gpu"); // applicable to windows os only
        firefoxOptions.addArguments("--disable-notifications"); //to disable notifications
        if (devTools) firefoxOptions.addArguments("-devtools");

        if (browserProfile) {
            // using firefox profile named "vois"
            // to skip the microsoft authenticator page
            ProfilesIni profileIni = new ProfilesIni();
            FirefoxProfile profile = profileIni.getProfile("vois");
            // opens network tab in dev tools
            profile.setPreference("devtools.toolbox.selectedTool", "netmonitor");
            firefoxOptions.setProfile(profile);
        }

        if (localDriver) {
            if (OS.contains("WIN")) {
                System.setProperty("webdriver.gecko.driver", "src/test/java/resource/geckodriver.exe");
            } else {
                System.setProperty("webdriver.gecko.driver", "src/test/java/resource/osx/geckodriver");
            }
        }

        FirefoxDriver firefoxDriver;
        try {
            firefoxDriver = new FirefoxDriver(firefoxOptions);
        } catch (Exception e) {
            if (OS.contains("WIN")) {
                String workingDirectory = System.getProperty("user.home");
                File pathBinary = new File(workingDirectory + File.separator + "AppData/Local/Mozilla Firefox/firefox.exe");
                FirefoxBinary firefoxBinary = new FirefoxBinary(pathBinary);
                firefoxOptions.setBinary(firefoxBinary);
            }
            firefoxDriver = new FirefoxDriver(firefoxOptions);
        }
        return firefoxDriver;
    }

    private static WebDriver createChromeWebDriver(final String OS, final boolean localDriver, final boolean devTools) {
        ChromeOptions chromeOptions = new ChromeOptions();
        chromeOptions.addArguments("--no-sandbox");
        chromeOptions.addArguments("--disable-dev-shm-usage"); // overcome limited resource problems
        chromeOptions.addArguments("--test-type");
        chromeOptions.addArguments("--disable-dev-shm-usage");
        chromeOptions.addArguments("--window-size=1920,1080");
        chromeOptions.addArguments("--disable-infobars"); // disabling infobars
        chromeOptions.addArguments("--disable-extensions"); // disabling extensions
        chromeOptions.addArguments("--disable-gpu"); // applicable to windows os only
        chromeOptions.addArguments("--disable-notifications"); //to disable notifications
        chromeOptions.addArguments("--incognito");
        if (devTools) chromeOptions.addArguments("--auto-open-devtools-for-tabs");

        if (localDriver) {
            if (OS.contains("MAC")) {
                System.setProperty("webdriver.chrome.driver", "src/test/java/resource/osx/chromedriver");
            } else {
                System.setProperty("webdriver.chrome.driver", "src/test/java/resource/chromedriver.exe");
            }
        }

        return new ChromeDriver(chromeOptions);
    }
}
