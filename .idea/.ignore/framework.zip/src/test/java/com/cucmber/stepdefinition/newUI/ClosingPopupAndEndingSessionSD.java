package com.cucmber.stepdefinition.newUI;

import com.cucmber.core.WebDriverActions;
import com.cucmber.core.helper.ScumberException;
import com.cucmber.page.closingPopupAndEndingSession.ClosingPopupAndEndingSessionHelper;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import org.openqa.selenium.WebDriver;

import java.util.logging.Logger;

public class ClosingPopupAndEndingSessionSD {
    private final static Logger Log = Logger.getLogger(ClosingPopupAndEndingSessionSD.class.getName());

    private ClosingPopupAndEndingSessionHelper closingPopupAndEndingSessionHelper;
    private WebDriver driver;

    public ClosingPopupAndEndingSessionSD() {
        Log.info("Constructor: Closing Popup And Ending Session");
    }

    @Before
    public void before(final Scenario scenario)
            throws ScumberException {
        driver = WebDriverActions.openBrowser(scenario);
        closingPopupAndEndingSessionHelper = new ClosingPopupAndEndingSessionHelper(driver);
    }

    @And("Customer Select New Complaint")
    public void customerSelectNewComplaint() {
        closingPopupAndEndingSessionHelper.customerSelectNewComplaint();
    }

    @And("Customer clicks on dedicated page")
    public void customerClicksOnDedicatedPage() {
        closingPopupAndEndingSessionHelper.customerClicksOnDedicatedPage();
    }

    @And("Open Chat Toggle")
    public void openChatToggle() {
        closingPopupAndEndingSessionHelper.openChatToggle();
    }
}