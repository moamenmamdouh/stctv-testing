package com.cucmber.page.closingPopupAndEndingSession;

import org.openqa.selenium.WebDriver;

import java.util.ArrayList;

public class ClosingPopupAndEndingSessionHelper extends ClosingPopupAndEndingSessionPO {
    public ClosingPopupAndEndingSessionHelper(final WebDriver itsDriver) {
        super(itsDriver);
    }

    public void customerSelectNewComplaint() {
        waitForVisible(NewComplaint);
        NewComplaint.click();
    }

    public void customerClicksOnDedicatedPage() {
        waitForVisible(DedicatedPage);
        DedicatedPage.click();

        ArrayList<String> tabs = new ArrayList<>(itsDriver.getWindowHandles());
        itsDriver.switchTo().window(tabs.get(0));
    }

    public void openChatToggle() {
        ChatToggle.click();
    }
}