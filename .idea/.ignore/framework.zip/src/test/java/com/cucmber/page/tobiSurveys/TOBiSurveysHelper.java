package com.cucmber.page.tobiSurveys;

import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class TOBiSurveysHelper extends TOBiSurveysPO {
    public TOBiSurveysHelper(final WebDriver driver) {
        super(driver);
    }

    public void customerClickOnCloseChatItem() {
        closeChat_Item.click();
    }

    public void verifyTOBiBotSurveyIsNotDisplayed() {
        assertTrue(endChatButton.isDisplayed());
        assertTrue(No_CTA.isDisplayed());
    }
}