package com.cucmber.stepdefinition;

import com.cucmber.core.WebDriverActions;
import com.cucmber.core.helper.ScumberException;
import com.cucmber.page.closeChat.CloseChatHelper;
import com.cucmber.page.common.CommonPo;
import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;

import static com.cucmber.core.helper.PropertiesLoader.readPropertyFile;

public class Hooks {
    private static final Logger Log = Logger.getLogger(Hooks.class.getName());
    private WebDriver itsDriver;

    public Hooks() {
        Log.info("Constructor: Hooks");
    }

    @Before
    public void before(final Scenario scenario) throws ScumberException, InterruptedException {
        final Properties props = readPropertyFile("config/config.properties");
        final String URL = System.getProperty("Env", props.getProperty("application.url"));
        itsDriver = WebDriverActions.openBrowser(scenario);
        // Add the required staging env header if we are running the test on the staging env to be able to access the staging env
        if (URL.contains("staging")) {
            itsDriver.get("https://login.vodafone.co.uk");
            Cookie newCookie = new Cookie.Builder(props.getProperty("staging.header.key"), props.getProperty("staging.header.value"))
                    .domain(".vodafone.co.uk")
                    .path("/")
                    .isSecure(false)
                    .build();
            itsDriver.manage().addCookie(newCookie);
        }
        // Go to the desired URL
        itsDriver.get(URL);
    }

    @AfterStep
    public void afterStep(final Scenario scenario) throws IOException {
        WebDriverActions.embedScreenShot(scenario, itsDriver);
    }

    @After()
    public void after(final Scenario scenario) throws IOException {
        Properties props = readPropertyFile("config/config.properties");
        CommonPo commonPo = new CommonPo(itsDriver);
            try {
                commonPo.userInputField.sendKeys("/chatinfo");
                commonPo.sendButton.click();
                String chatID;
                chatID = itsDriver.findElements(By.cssSelector("[class*='styled__KeyValue-']")).get(2).getText();
                scenario.log("INFO: ChatID: " + chatID);
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
                LocalDateTime now = LocalDateTime.now();

                List<String[]> dataLines = new ArrayList<>();
                dataLines.add(new String[]
                        {scenario.getName(), scenario.getName(), dtf.format(now), scenario.getStatus().toString(), chatID});
                givenDataArray_whenConvertToCSV_thenOutputCreated(dataLines);
            } catch (Exception e) {
                scenario.log("Couldn't Get Chat ID");
            }

            if (props.getProperty("remote").equalsIgnoreCase("true") || !scenario.isFailed()) {
                try {
                    CloseChatHelper close_chat_helper = new CloseChatHelper(itsDriver);
                    close_chat_helper.click_on_close_CTA();
                    close_chat_helper.click_on_end_CTA();
                } catch (Exception e) {
                    scenario.log("Couldn't close chat");
                }
                itsDriver.manage().deleteAllCookies();
                WebDriverActions.closeBrowser(scenario, itsDriver);
            }
            itsDriver = null;
    }

    public String convertToCSV(String[] data) {
        return String.join(",", data);
    }

    public void givenDataArray_whenConvertToCSV_thenOutputCreated(List<String[]> dataLines) throws IOException {
        File file = new File("DailyRun.csv");
        FileWriter fr = new FileWriter(file, true);
        BufferedWriter br = new BufferedWriter(fr);
        PrintWriter pr = new PrintWriter(br);
        dataLines.stream()
                .map(this::convertToCSV)
                .forEach(pr::println);
        pr.close();
        br.close();
        fr.close();
    }
}
