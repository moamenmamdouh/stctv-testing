package com.cucmber.page.tobiIcons;

import org.openqa.selenium.WebDriver;

public class TOBiIconsHelper extends TOBiIconsPO {

    public TOBiIconsHelper(final WebDriver driver) {
        super(driver);
    }

    public void verifyTobiIconDisplay(String tobiIcon) {
        waitForVisible(TobiIcon);
        assertElementAttributeContainsText(TobiIcon, tobiIcon.toLowerCase(), "data-src");
    }
}
