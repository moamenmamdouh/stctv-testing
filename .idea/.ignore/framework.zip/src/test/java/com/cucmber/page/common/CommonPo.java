package com.cucmber.page.common;

import com.cucmber.core.utils.AbstractBasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import java.util.List;

import static com.cucmber.page.common.CommonHelper.Count;

public class CommonPo extends AbstractBasePage {

    @FindAll({@FindBy(how = How.CSS, using = "[data-cy='tobi-toggle-btn']"), @FindBy(how = How.ID, using = "active-title")
    })
    public WebElement ChatToggle;
    @FindBy(how = How.CSS, using = "button[aria-label='End chat']")
    public WebElement endChatButton;
    @FindBy(how = How.XPATH, using = "//button[contains(text(),'No')]")
    public WebElement No_CTA;
    /**
     * Final Implementation
     * <p>
     * Old implementation commented below
     */
    @FindBy(how = How.ID, using = "onetrust-banner-sdk")
    public WebElement acceptCookiesFrame;
    @FindBy(how = How.ID, using = "onetrust-accept-btn-handler")
    public WebElement acceptCookiesButton;
    @FindBy(how = How.ID, using = "onetrust-consent-sdk")
    public WebElement acceptCookiesSdk;
    @FindBy(how = How.CSS, using = "button[data-cy*='quick-replies-']")
    public List<WebElement> quickRepliesElements;
    @FindBy(how = How.CSS, using = "td.tcChat_agentLine.tcChat_openerLine")
    public WebElement oldUIFirstMessage;
    //    @FindAll({
//            @FindBy(how = How.CSS, using = "[class*='styled__MessageInner']"),
//            @FindBy(how = How.CLASS_NAME, using = "agentMsg")
//    })
//    public List<WebElement> tobiSays;
    @FindBy(how = How.CSS, using = "[aria-label='more']")
    public WebElement threeDots_CTA;
    @FindBy(how = How.XPATH, using = "//h1[contains(text(),'Log in to TOBi')]")
    public WebElement loginTitle;
    @FindBy(how = How.XPATH, using = "//input[@name='phonenumber']")
    public WebElement ctnField;
    @FindBy(how = How.ID, using = "user")
    public WebElement usernameField;
    @FindBy(how = How.ID, using = "pass")
    public WebElement passwordField;
    @FindBy(how = How.XPATH, using = "//button[contains(text(),'Continue')]")
    public WebElement continue_button;
    @FindBy(how = How.XPATH, using = "//button[contains(text(),'Back')]")
    public WebElement back_button;
    @FindBy(how = How.XPATH, using = "//button[contains(text(),'Log')]")
    public WebElement login_button;
    @FindBy(how = How.XPATH, using = "//iframe[@title='login']")
    public WebElement iframeAcceptCookiesDXIDM;
    @FindBy(how = How.ID, using = "submit-otp-0")
    public WebElement otac_01;
    @FindBy(how = How.ID, using = "submit-otp-1")
    public WebElement otac_02;
    @FindBy(how = How.ID, using = "submit-otp-2")
    public WebElement otac_03;
    @FindBy(how = How.ID, using = "submit-otp-3")
    public WebElement otac_04;
    @FindBy(how = How.ID, using = "submit-otp-4")
    public WebElement otac_05;
    @FindBy(how = How.ID, using = "personDOB-day")
    public WebElement dateOfBirthDay;
    @FindBy(how = How.ID, using = "personDOB-month")
    public WebElement dateOfBirthMonth;
    @FindBy(how = How.ID, using = "personDOB-year")
    public WebElement dateOfBirthYear;
    @FindBy(how = How.ID, using = "firstName")
    public WebElement firstName;
    @FindBy(how = How.ID, using = "lastName")
    public WebElement lastName;
    @FindBy(how = How.ID, using = "enter-pin-0")
    public WebElement pin_01;
    @FindBy(how = How.ID, using = "enter-pin-1")
    public WebElement pin_02;
    @FindBy(how = How.ID, using = "enter-pin-2")
    public WebElement pin_03;
    @FindBy(how = How.ID, using = "enter-pin-3")
    public WebElement pin_04;
    @FindBy(how = How.XPATH, using = "//h1[contains(text(),'Request security code')]")
    public WebElement securityCodeScreenTitle;
    @FindBy(how = How.NAME, using = "choosePhone")
    public WebElement choosePhoneDrp;
    @FindBy(how = How.CSS, using = "button[aria-label='login popup close icon']")
    public WebElement closeDXIDM_button;
    @FindBy(how = How.NAME, using = "billing-details-button")
    public WebElement billDetailsButton;
    @FindBy(how = How.ID, using = "back-button")
    public WebElement backButton;
    @FindBy(css = "button[class*='Interactionstyle__Button-sc-e1xkgc-0 hpjIeb Tags']")
    public WebElement newMessageButton;
    @FindBy(css = "[aria-label='Go to basket']")
    public WebElement basket;

    @FindBy(css = ".Headingstyle__Heading-sc-12vluu2-0.gbZrJY")
    public WebElement reviewYourBasketTxt;

    @FindAll({
            @FindBy(how = How.XPATH, using = "(//*[contains(@data-src,'/icons/state-success')])"),
            @FindBy(how = How.XPATH, using = "(//*[contains(@data-src,'/icons/state-error')])")
    })
    public WebElement iconState;
    @FindBy(css = "[aria-label='Type here to talk to TOBi']")
    public WebElement userInputField;
    @FindBy(css = "[aria-label='Send message']")
    public WebElement sendButton;
    @FindBy(how = How.CSS, using = "[class*='styled__MessageInner']")
    public List<WebElement> tobiSays;
    @FindBy(how = How.CSS, using = "div[id*='message-index']")
    public List<WebElement> allMessagesCount;
    @FindBy(how = How.XPATH, using = "(//li[contains(@class,'ListItemstyle')]/p)")
    public List<WebElement> ErrorChecklistNames;
    @FindBy(how = How.XPATH, using = "(//*[contains(@data-src,'/icons/state-')])")
    public List<WebElement> ErrorChecklistIcons;
    WebDriver driver;

    public CommonPo(final WebDriver driver) {
        super(driver);
        this.driver = driver;
    }

    public List<WebElement> buttonsWithAriaLabel(String buttonText) {
        return driver.findElement(By.id("tobi-ui-root")).findElements(By.cssSelector("button[aria-label*=\"" + buttonText + "\"]"));
    }

    public WebElement buttonWithValue(String buttonText) {
        // check exact text first
        List<WebElement> exactTextLastElementList = driver.findElement(By.id("tobi-ui-root")).findElements(By.xpath("(//button[.=\"" + buttonText + "\"])[last()]"));
        if (!exactTextLastElementList.isEmpty())
            return exactTextLastElementList.get(0);
        else {
            // if exact text wasn't found, check by containing the text
            List<WebElement> containsTextLastElementList = driver.findElement(By.id("tobi-ui-root")).findElements(By.xpath("(//button[contains(.,\"" + buttonText + "\")])[last()]"));
            if (!containsTextLastElementList.isEmpty())
                return containsTextLastElementList.get(0);
            else
                return null; // return null if no button with matching text was found
        }
    }

    public WebElement buttonWithValueInCurrentResponse(String buttonText) {
        // check exact text first
        List<WebElement> exactTextLastElementList = driver.findElement(By.id("tobi-ui-root")).findElement(By.id("message-index-" + Count)).findElements(By.xpath("(//button[.=\"" + buttonText + "\"])"));
        if (!exactTextLastElementList.isEmpty())
            return exactTextLastElementList.get(0);
        else {
            // if exact text wasn't found, check by containing the text
            List<WebElement> containsTextLastElementList = driver.findElement(By.id("tobi-ui-root")).findElement(By.id("message-index-" + Count)).findElements(By.xpath("(//button[contains(.,\"" + buttonText + "\")])"));
            if (!containsTextLastElementList.isEmpty())
                return containsTextLastElementList.get(0);
            else
                return null; // return null if no button with matching text was found
        }
    }

    public void billDetailsCardText(String text) {
        driver.findElement(By.id("tobi-ui-root")).findElement(By.xpath("//div[contains(.,\"" + text + "\")]"));
    }

    public List<WebElement> choosePlanList() {
        List<WebElement> choosePlanList = driver.findElements(By.xpath("//button[@aria-label='Choose plan']"));
        if (choosePlanList.size() > 0) {
            return choosePlanList;
        } else {
            System.out.println("There No Plan Cards");
        }
        return choosePlanList;
    }

    public List<WebElement> AddPlanList() {
        List<WebElement> AddPlanList = driver.findElements(By.xpath("//button[@aria-label='Add']"));
        if (AddPlanList.size() > 0) {
            return AddPlanList;
        } else {
            System.out.println("There No Plan Cards");
        }
        return AddPlanList;
    }

    public List<WebElement> AddToPlan() {
        List<WebElement> choosePlanList = driver.findElements(By.xpath("//*[@id=\"message-index-25\"]/div/div/div/div[2]/div/div/div[3]/div/div/div/button"));
        if (choosePlanList.size() > 0) {
            return choosePlanList;
        } else {
            System.out.println("There No Plan Cards");
        }
        return choosePlanList;
    }
}