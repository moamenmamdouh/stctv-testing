package com.cucmber.page.resetChat;

import org.openqa.selenium.WebDriver;

public class ResetChatHelper extends ResetChatPo {

    public ResetChatHelper(final WebDriver driver) {
        super(driver);
    }

    public void Click_on_Three_Dot_CTA() {
        threeDots_CTA.click();
    }

    public void Click_on_Reset_Chat_CTA() {
        Reset_Chat_CTA.click();
    }

    public void validate_text_not_present_in_list(String text) {
        implicitWaitAndSleep(25);
        checkIfTextOfAnElementIsNotPresentInAList(tobiSays, text);
    }
}