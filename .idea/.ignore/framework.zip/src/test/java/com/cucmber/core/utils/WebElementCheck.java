package com.cucmber.core.utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.logging.Logger;

import static org.junit.jupiter.api.Assertions.*;

public class WebElementCheck extends WebElementWait {
    private final static Logger Log = Logger.getLogger(WebElementCheck.class.getName());
    int foundExpectedResponseIndex;

    public WebElementCheck(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    /**
     * @param element      - web element
     * @param valueToCheck - text to check
     */
    public boolean checkTextToBePresentInElement(final WebElement element, final String valueToCheck) {
        final WebDriverWait itsWait = new WebDriverWait(itsDriver, Duration.ofSeconds(30));
        return itsWait.until(ExpectedConditions.textToBePresentInElement(element, valueToCheck)).booleanValue();
    }

    /**
     * This method will assert/check for true output of a condition
     *
     * @param message          - message when the output of condition is false
     * @param conditionToCheck - condition to evaluate
     */
    protected void assertCheckIfTrue(final String message, final boolean conditionToCheck) {
        assertTrue(conditionToCheck, message);
    }

    /**
     * This method will assert/check for false output of a condition
     *
     * @param message          - message when the output of condition is true
     * @param conditionToCheck - condition to evaluate
     */
    protected void assertCheckIfFalse(final String message, final boolean conditionToCheck) {
        assertFalse(conditionToCheck, message);
    }

    /**
     * This method will go through all the texts of the elements to check is a text is present
     *
     * @param listOfElements - list of Elements
     * @param textToCheck    - value that needs to be replaced from xpath
     */
    // checking if the text is present in the last 5 elements of tobi responses and return it if found, else return null
    protected WebElement checkIfTextOfAnElementIsPresentInAList(final List<WebElement> listOfElements, final String textToCheck) {
        boolean textIsFound = false;
        WebElement elementToFind = null;
        int loop = 1;
        // set for loop start with the minimum of size-5 or size
        int minOfFiveOrElementSize = Math.min(listOfElements.size(), 5);
        // hashset recording the last 5 tobi responses elements, to view in case of failure to find text
        final List<String> textFromElements = new ArrayList<>();

        // loop for the last 5 Tobi responses, check if text is present in any of the last 5 elements
        for (int elementIndex = listOfElements.size() - minOfFiveOrElementSize; elementIndex < listOfElements.size(); elementIndex++) {
            // get the current iteration element
            WebElement iteratedWebElement = listOfElements.get(elementIndex);
            // if text is found in the iterated element
            if (iteratedWebElement.getText().trim().contains(textToCheck)) {
                elementToFind = iteratedWebElement;
                textIsFound = true;
                break;
            }
            // add element to the hashset as it doesn't match the text we are searching for
            textFromElements.add("\n\t------------------------ " + loop + " -----------------------------" + "\n" + "{" + listOfElements.get(elementIndex).getText().trim() + "}");
            loop++;
        }

        // if text isn't found in any of the last responses, print the last 5 elements
        if (!textIsFound) {
            assertFail(String.format("\nFAIL: The following string:\n\t'%s'\nwasn't found in the last 5 messages list: %s\n\t--------------------------------------------------------", textToCheck, textFromElements));
        }
        // return the element if found, else returns null
        return elementToFind;
    }


    protected By checkIfTextOfLastElementIsPresentInAList(int Index, final String textToCheck) {
        By elementLocator = By.id("message-index-" + Index);
        WebElement TextContainer = itsDriver.findElement(elementLocator);
        String ExpectedText = TextContainer.getText().trim();
        if (!ExpectedText.contains(textToCheck)) {
            assertFail(String.format("\nFAIL: The following string (Expected):\n\t{%s}\nwasn't found in the last Message (Actual): \n\t{%s}\n\t--------------------------------------------------------", textToCheck, ExpectedText));
        }
        // return the element By if found, else returns null
        return elementLocator;
    }

    protected By checkIfAnyExpectedTextIsPresentInLastResponse(int Index, final List<String> expectedResponses) {
        By elementLocator = By.id("message-index-" + Index);
        WebElement TextContainer = itsDriver.findElement(elementLocator);
        String actualResponse = TextContainer.getText().trim();
        foundExpectedResponseIndex = 0;
        for (String expectedText : expectedResponses) {
            if (actualResponse.contains(expectedText)) {
                //indexInList
                // return the element if found, else returns null
                return elementLocator;
            }
            foundExpectedResponseIndex++;
        }
        for (String expectedText : expectedResponses) {
            assertFail(String.format("\nFAIL: The following string (Expected):\n\t{%s}\nwasn't found in the last Message (Actual): \n\t{%s}\n\t--------------------------------------------------------", expectedText, actualResponse));
        }
        return null;
    }

    protected void verifyThatThisResponseAlsoContainsTheCorrespondingSentence(By lastVerifiedTobiResponseWebElement, List<String> tobiResponses) {
        String tobiResponse = tobiResponses.get(foundExpectedResponseIndex);
        WebElement myElement = itsDriver.findElement(lastVerifiedTobiResponseWebElement);
        if (lastVerifiedTobiResponseWebElement != null)
            assertCheckIfTrue(String.format("FAIL: Text (Expected):\n\t{%s}\nisn't found in the element (Actual): \n\t{%s}\n\t-------------------------------------------------------- ", tobiResponse, myElement.getText()), myElement.getText().contains(tobiResponse));
        else assertFail("FAIL: Element wasn't found");
    }


    /**
     * This method checks if the object is not null
     *
     * @param message              - message if the object is NULL
     * @param objectToCheckNotNull - an Object to check
     */
    protected void assertCheckIfNotNull(final String message, final Object objectToCheckNotNull) {
        assertNotNull(objectToCheckNotNull, message);
    }

    /**
     * This method will go through all the texts of the elements to check is a text is NOT present
     *
     * @param listOfElements - list of Elements
     * @param textToCheck    - value that needs to be replaced from xpath
     */
    public void checkIfTextOfAnElementIsNotPresentInAList(final List<WebElement> listOfElements, final String textToCheck) {
        final HashSet<String> textFromElements = new HashSet<String>();

        for (final WebElement element : listOfElements) {
            textFromElements.add(element.getText().trim());
        }

        assertCheckIfFalse(String.format("FAIL: value '%s' is present in the list : %s ", textToCheck, textFromElements), textFromElements.contains(textToCheck));
    }

    /**
     * @param message
     */
    public void assertFail(final String message) {
        fail(message);
    }

    /**
     * Check if element is visible or not
     *
     * @param webElement
     * @param message
     */
    public void assertElementIsVisible(final WebElement webElement, final String message) {
        waitForVisible(webElement);
        assertTrue(webElement.isDisplayed(), message);
    }

    /**
     * Check if text is present for selected object
     *
     * @param webElement
     * @param message
     * @param text
     */
    public void assertTextIsVisible(final WebElement webElement, final String message, final String text) {
        final String elementText = webElement.getText();
        assertTrue(elementText.contains(text), message + elementText);
    }

    /**
     * @param element
     * @param expectedText
     */
    public void assertElementText(final WebElement element, final String expectedText) {
        final String message = String.format("FAIL : Element doesn't contain this text '%s'", expectedText);
        final String actualText = element.getText();
        if (actualText != null) assertEquals(expectedText, actualText, message);
        else assertFail("FAIL: Element's Text is null");
    }

    /**
     * This method is loop in the all reply and check if these Text appear on the chat
     *
     * @param QuickRepliesElements the list of replies from tobi
     * @param textToCheck          the text which we're searching for it
     */
    protected void checkIfTextOfTheQuickReplyPresentInAList(final List<WebElement> QuickRepliesElements, final String textToCheck) {
        if (QuickRepliesElements.isEmpty()) assertFail("FAIL: No quick replies were found");
        else {
            final HashSet<String> textFromElements = new HashSet<>();

            for (final WebElement element : QuickRepliesElements) {
                textFromElements.add(element.getText().trim());
            }
            assertCheckIfTrue(String.format("\nFAIL: The following text:\n\t'%s'\nwasn't found in the quick replies:\n%s\n\t--------------------------------------------------------", textToCheck, textFromElements), textFromElements.contains(textToCheck));
        }
    }

    /**
     * Check if the value of an element attribute contains a text
     *
     * @param element      the element that includes "attribute"
     * @param expectedText te expected text to match the subtext of the "attribute" value
     * @param attribute    The attribute of "element"
     */
    public void assertElementAttributeContainsText(final WebElement element, final String expectedText, final String attribute) {
        final String message = String.format("FAIL : Element is not having this text '%s'", expectedText);
        final String actualText = element.getAttribute(attribute);
        if (actualText != null) assertTrue(actualText.contains(expectedText), message);
        else assertFail("FAIL: Element's attribute is null");
    }

    /**
     * returns true if screen with the passed element was found, false otherwise.
     * Doesn't stop/fail the script if the screen wasn't found.
     *
     * @param webElement - any web element within the needed screen
     */
    protected boolean screenAppeared(final WebElement webElement) {
        try {
            return webElement.isDisplayed();
        } catch (Exception e) {
            Log.info("Screen didn't appear.");
            return false;
        }
    }

    /**
     * returns true if element is present within the page, false otherwise.
     * Doesn't stop/fail the script if the element wasn't found.
     *
     * @param by - element locator
     */
    public boolean elementPresent(By by) {
        boolean isPresent = true;
        waitForLoad();
        //search for elements and check if list is empty
        if (getDriver().findElements(by).isEmpty()) {
            isPresent = false;
        }
        //rise back implicitly wait time
        itsDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        return isPresent;
    }
}
