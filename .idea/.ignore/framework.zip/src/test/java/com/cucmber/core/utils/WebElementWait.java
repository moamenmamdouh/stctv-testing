package com.cucmber.core.utils;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.logging.Logger;

import static org.junit.jupiter.api.Assertions.assertNotNull;

public abstract class WebElementWait {
    public final static int WAIT_TIMEOUT_DEFAULT = 120;
    private final static Logger Log = Logger.getLogger(WebElementWait.class.getName());
    protected final WebDriver itsDriver;
    protected final WebDriverWait itsWait;

    public WebElementWait(final WebDriver driver) {
        itsDriver = driver;
        PageFactory.initElements(driver, this);
        itsWait = createWebWaitDriver(WAIT_TIMEOUT_DEFAULT);
    }

    public WebDriver getDriver() {
        return itsDriver;
    }

    /**
     * <!-- ================================================================================================== -->
     *
     * @param message
     * @param element
     * @lastrev fixXXXXX - New method
     * <!-- ------------------------------------------------------------------------------------------------ -->
     */
    private void assertCheckIfNotNull(final String message, final WebElement element) {
        assertNotNull(element, message);
    }

    /**
     * <!-- ================================================================================================== -->
     * This method will wait till element is Clickable
     *
     * @param element
     * @lastrev fixXXXXX - New method
     * <!-- ------------------------------------------------------------------------------------------------ -->
     */
    protected void waitUntilElementIsClickable(final WebElement element) {
        final String message = String.format("FAIL : Element with these details is NULL : '%s'", element);
        assertCheckIfNotNull(message, element);
        itsWait.until(ExpectedConditions.elementToBeClickable(element));
    }

    /**
     * <!-- ================================================================================================== -->
     * This method creates a WebDriverWait
     *
     * @param timeOutInSeconds
     * @return
     * @lastrev fixXXXXX - New method
     * <!-- ------------------------------------------------------------------------------------------------ -->
     */
    protected WebDriverWait createWebWaitDriver(final long timeOutInSeconds) {
        return new WebDriverWait(itsDriver, Duration.ofSeconds(timeOutInSeconds));
    }

    /**
     * This method waits until the element is visible
     *
     * @param element - WebElement
     * @param seconds - seconds to wait before skipping
     */
    protected void waitForVisible(final WebElement element, int seconds) {
        WebDriverWait webDriverWait = createWebWaitDriver(seconds);
        webDriverWait.until(ExpectedConditions.visibilityOf(element));
    }

    protected void waitForVisibleWithoutFailure(final WebElement element, int seconds) {
        try {
            waitForVisible(element, seconds);
        } catch (Exception e) {
            System.out.printf("Element didn't appear after waiting '%s' seconds%n", seconds);
        }
    }

    /**
     * Waits for given amount of time, Since it affects state in the driver we should undo it using a finally.
     *
     * @param time
     * @lastrev fixXXXXX - New method
     * <!-- ------------------------------------------------------------------------------------------------ -->
     */
    public void implicitWaitAndSleep(final int time) {
        try {
            Thread.sleep(time * 1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        itsDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(time));
    }

    public void implicitWait(final int time) {

        itsDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(time));
    }

    /**
     * Waits for element to be visible within 30 sec
     *
     * @param webElement
     * @lastrev fixXXXXX - New method
     * <!-- ------------------------------------------------------------------------------------------------ -->
     */
    public void waitForVisible(final WebElement webElement) {
        itsWait.until(ExpectedConditions.visibilityOf(webElement));
    }

    /**
     * method to wait until the message with specific index be invisible.
     *
     * @param 'Index' the index of message that want to wait until be visible
     */
    public void waitForInvisible(final WebElement webElement) {
        itsWait.until(ExpectedConditions.invisibilityOf(webElement));
    }

    /**
     * method to wait until the message with specific index be invisible.
     *
     * @param Index the index of message that want to wait until be visible
     */
    public void waitForVisibleTextByIndex(String Index) {
        itsWait.until(ExpectedConditions.visibilityOfElementLocated(By.id("message-index-" + Index)));
    }
    /**
     * method to wait until the message with specific index be invisible.
     *
     * @param Index the index of message that want to wait until be visible
     * @param seconds the timeout pre second
     */
    public void waitForVisibleTextByIndex(String Index, int seconds) {
        WebDriverWait wait = new WebDriverWait(itsDriver, Duration.ofSeconds(seconds));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("message-index-" + Index)));
    }

    public void waitForLoad() {
        ExpectedCondition<Boolean> pageLoadCondition = wd -> {
            //this will tell if page is loaded
            return "complete".equals(((JavascriptExecutor) wd).executeScript("return document.readyState"));
        };
        //wait for page complete
        itsWait.until(pageLoadCondition);
        //lower implicitly wait time
        itsDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(100));
    }
}