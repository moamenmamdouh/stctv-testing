package com.cucmber.page.sizeText;

import com.cucmber.page.common.CommonPo;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class SizeTextPo extends CommonPo {

    @FindBy(how = How.XPATH, using = "//*[@id=\"tobi-ui-root\"]/div[1]/div/div[1]/div/div[1]/div[2]/div/div/ul/li[2]/button")
    WebElement change_text_size_CTA;
    @FindBy(css = "[class*='styled__MessageInner']")
    WebElement response_text;

    public SizeTextPo(final WebDriver driver) {
        super(driver);
    }
}