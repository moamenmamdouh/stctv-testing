package com.cucmber.core.utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Logger;

public abstract class AbstractBasePage extends WebElementHelperMethods {
    private final static Logger Log = Logger.getLogger(AbstractBasePage.class.getName());

    protected AbstractBasePage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    /**
     * Get element text or attribute value
     */
    protected String getElementText(final WebElement element) {
        waitForVisible(element);
        final String buttonText = element.getAttribute("value");
        return !buttonText.equals("") ? buttonText : element.getText();
    }

    /**
     * Returns the value of the color attribute for that element
     *
     * @param colorAttribute = "color" or "background-color"
     */
    protected String getElementColor(final WebElement element, final String colorAttribute) {
        waitForVisible(element);
        return element.getCssValue(colorAttribute);
    }

    /**
     * Returns the value of the attribute for that element
     *
     * @param attribute = "class", "id" etc.
     */
    protected String getElementAttribute(final WebElement element, final String attribute) {
        return element.getAttribute(attribute);
    }

    /**
     * Check date time format
     *
     * @param format
     * @param value
     * @return
     */
    protected boolean isValidDateTimeFormat(final String format, final String value) {
        try {
            final SimpleDateFormat sdf = new SimpleDateFormat(format);
            sdf.parse(value);
            return true;
        } catch (final ParseException ex) {
            return false;
        }
    }

    /**
     * Get current date in the given format
     *
     * @param format
     * @return
     */
    protected String getCurrentDateWithFormat(final String format) {
        final DateFormat dateFormat = new SimpleDateFormat(format);
        final Date date = new Date();
        return dateFormat.format(date);
    }

    /**
     * Method to return past date
     *
     * @return string date
     */
    public String getPastDate(final String format, final int iDays) {
        final DateFormat dateFormat = new SimpleDateFormat(format);
        final Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, -iDays);
        return dateFormat.format(cal.getTime());
    }
}
