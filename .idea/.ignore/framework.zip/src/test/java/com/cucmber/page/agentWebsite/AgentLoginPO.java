package com.cucmber.page.agentWebsite;

import com.cucmber.page.common.CommonPo;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class AgentLoginPO extends CommonPo {

    @FindBy(how = How.ID, using = "username")
    WebElement AgentUsername_txt;
    @FindBy(how = How.ID, using = "password")
    WebElement AgentPassword_txt;
    @FindBy(how = How.XPATH, using = "//button[@class='submit']")
    WebElement SubmitLogin_btn;
    @FindBy(how = How.XPATH, using = "(//button[@type='button'])[2]")
    WebElement DropDownMenuStatus;
    @FindBy(how = How.XPATH, using = "(//li[contains(@class,'MuiMenuItem-root MuiMenuItem-gutters')])[1]")
    WebElement AgentAvailableStatus;
    @FindBy(how = How.XPATH, using = "(//li[contains(@class,'MuiMenuItem-root MuiMenuItem-gutters')])[2]")
    WebElement AgentBusyStatus;

    public AgentLoginPO(WebDriver driver) {
        super(driver);
    }
}
