package com.cucmber.page.closeChat;

import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.Assertions.assertFalse;

public class CloseChatHelper extends CloseChatPo {


    public CloseChatHelper(final WebDriver driver) {
        super(driver);
    }

    public void click_on_close_CTA() {
        waitUntilElementIsClickable(close_CTA);
        close_CTA.click();
    }

    public void click_on_end_CTA() {
        waitUntilElementIsClickable(endChatButton);
        endChatButton.click();
    }

    public void click_on_no_CTA() {
        waitUntilElementIsClickable(No_CTA);
        No_CTA.click();
    }

    public void validate_chat_closed() {
        assertFalse(close_CTA.isDisplayed());
        // Assert.assertTrue(ChatToggle.isDisplayed());
    }

    public void validate_chat_not_closed() {
        assertElementIsVisible(close_CTA, "close CTA Displayed");
    }
}
