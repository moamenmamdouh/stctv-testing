package com.cucmber.stepdefinition.newUI;

import com.cucmber.core.WebDriverActions;
import com.cucmber.core.helper.ScumberException;
import com.cucmber.page.tobiSurveys.TOBiSurveysHelper;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebDriver;

import java.util.logging.Logger;

public class TOBiSurveysSD {
    private final static Logger Log = Logger.getLogger(TOBiSurveysSD.class.getName());

    private TOBiSurveysHelper toBiSurveysHelper;
    private WebDriver driver;

    public TOBiSurveysSD() {
        Log.info("Constructor: Trigger TOBi Surveys");
    }

    @Before
    public void before(final Scenario scenario)
            throws ScumberException {
        driver = WebDriverActions.openBrowser(scenario);
        toBiSurveysHelper = new TOBiSurveysHelper(driver);
    }

    @And("Customer Click On Close Chat Item")
    public void customerClickOnCloseChatItem() {
        toBiSurveysHelper.customerClickOnCloseChatItem();
    }

    @Then("Verify TOBi Bot Survey Is Not Displayed")
    public void verifyTOBiBotSurveyIsNotDisplayed() {
        toBiSurveysHelper.verifyTOBiBotSurveyIsNotDisplayed();
    }
}