package com.cucmber.page.tobiSurveys;

import com.cucmber.page.common.CommonPo;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class TOBiSurveysPO extends CommonPo {
    @FindBy(how = How.XPATH, using = "//*[@id=\"tobi-ui-root\"]/div[1]/div/div[1]/div/div[1]/div[2]/div/div/ul/li[4]/button")
    WebElement closeChat_Item;

    public TOBiSurveysPO(final WebDriver driver) {
        super(driver);
    }
}