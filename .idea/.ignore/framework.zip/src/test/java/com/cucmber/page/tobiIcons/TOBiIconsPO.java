package com.cucmber.page.tobiIcons;

import com.cucmber.page.common.CommonPo;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class TOBiIconsPO extends CommonPo {

    @FindAll({
            @FindBy(how = How.XPATH, using = "(//*[contains(@data-src,'/icons/tobi')])"),
            @FindBy(how = How.XPATH, using = "(//*[contains(@data-src,'/icons/hearts')])")
    })
    public WebElement TobiIcon;

    public TOBiIconsPO(final WebDriver driver) {
        super(driver);
    }
}
