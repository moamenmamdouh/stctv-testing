package com.cucmber.page.minimizeChat;

import com.cucmber.page.common.CommonPo;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class MinimizeChatpo extends CommonPo {

    @FindBy(how = How.CSS, using = "[aria-label='Minimize Tobi chat']")
    WebElement minimize_CTA;

    public MinimizeChatpo(final WebDriver driver) {
        super(driver);
    }
}