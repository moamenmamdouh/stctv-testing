package com.cucmber.stepdefinition.newUI;

import com.cucmber.core.WebDriverActions;
import com.cucmber.core.helper.ScumberException;
import com.cucmber.page.sizeText.SizeTextHelper;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;

import java.util.logging.Logger;

public class SizeTextSD {

    private final static Logger Log = Logger.getLogger(SizeTextSD.class.getName());

    private SizeTextHelper sizeTextHelper;
    private WebDriver itsDriver;

    public SizeTextSD() {
        Log.info("Constructor: SizeTextSD");
    }

    @Before
    public void before(final Scenario scenario)
            throws ScumberException {
        itsDriver = WebDriverActions.openBrowser(scenario);
        sizeTextHelper = new SizeTextHelper(itsDriver);
    }

    @When("customer click on Three Dot")
    public void customer_click_on_Three_Dot() {
        sizeTextHelper.Click_on_Three_Dot();
    }

    @And("customer click on change text size CTA")
    public void customerClickOnChangeTextSizeCTA() {
        sizeTextHelper.Click_on_change_Text_Size();
    }

    @Then("validate size changed")
    public void validateSizeChange() {
        sizeTextHelper.compare_sizes_of_text();
    }

    @When("customer check size of text")
    public void customerCheckSizeOfText() {
        sizeTextHelper.Check_size_of_Text();
    }
}
