package com.cucmber.page.screenSizesResponsive;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.Assertions.*;

public class ScreenSizesResponsiveHelper extends ScreenSizesResponsivePO {
    Point chatBoxBoarder_Desktop;
    Point chatBoxBoarder_Tablet;
    String chatBoxBoarder_Mobile;

    public ScreenSizesResponsiveHelper(final WebDriver driver) {
        super(driver);
    }

    public void chatBoxIsInDesktopMode() {
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        chatBoxBoarder_Desktop = ChatBox.getLocation();
    }

    public void desktopModeIsResponsive() {
        assertTrue(threeDots_CTA.isDisplayed());
    }

    public void chatBoxIsInTabletMode() {
        Dimension dimension = new Dimension(768, 1024);
        itsDriver.manage().window().setSize(dimension);

        chatBoxBoarder_Tablet = ChatBox.getLocation();
    }

    public void tabletModeIsResponsive() {
        assertNotEquals(chatBoxBoarder_Desktop, chatBoxBoarder_Tablet);
        assertTrue(threeDots_CTA.isDisplayed());
    }

    public void chatBoxIsOpenedInMobileSize() {
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Dimension dimension = new Dimension(360, 640);
        itsDriver.manage().window().setSize(dimension);
    }

    public void mobileModeIsResponsive() {
        chatBoxBoarder_Mobile = ChatBox.getCssValue("border-radius");
        assertEquals("0px", chatBoxBoarder_Mobile);
        assertTrue(threeDots_CTA.isDisplayed());
    }
}