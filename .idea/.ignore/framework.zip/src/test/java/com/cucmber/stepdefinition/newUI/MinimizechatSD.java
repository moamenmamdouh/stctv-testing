package com.cucmber.stepdefinition.newUI;

import com.cucmber.core.WebDriverActions;
import com.cucmber.core.helper.ScumberException;
import com.cucmber.page.minimizeChat.MinimizeChatHelper;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;

import java.util.logging.Logger;

public class MinimizechatSD {

    private final static Logger Log = Logger.getLogger(MinimizechatSD.class.getName());

    private MinimizeChatHelper minimize_chat_helper;
    private WebDriver itsDriver;

    public MinimizechatSD() {
        Log.info("Constructor: MinimizechatSD");
    }

    @Before
    public void before(final Scenario scenario)
            throws ScumberException {
        itsDriver = WebDriverActions.openBrowser(scenario);
        minimize_chat_helper = new MinimizeChatHelper(itsDriver);
    }

    @When("customer click on minimize CTA")
    public void customer_click_on_minimize_CTA() {
        minimize_chat_helper.minimize_chat();
    }

    @Then("validate chat minimized")
    public void validateChatMinimized() {
        minimize_chat_helper.validate_chat_minimized();
    }

    @When("click on chat again")
    public void clickOnChatAgain() {
        minimize_chat_helper.open_Chat_icon();
    }
}
