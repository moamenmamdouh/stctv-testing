package com.cucmber.page.closingPopupAndEndingSession;

import com.cucmber.page.common.CommonPo;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;


public class ClosingPopupAndEndingSessionPO extends CommonPo {
    @FindBy(how = How.XPATH, using = "//button[contains(text(),\"I'm making a new complaint\")]")
    public WebElement NewComplaint;
    @FindBy(linkText = "dedicated page")
    public WebElement DedicatedPage;

    public ClosingPopupAndEndingSessionPO(final WebDriver driver) {
        super(driver);
    }
}