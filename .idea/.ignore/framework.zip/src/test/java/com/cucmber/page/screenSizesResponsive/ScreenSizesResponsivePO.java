package com.cucmber.page.screenSizesResponsive;

import com.cucmber.page.common.CommonPo;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ScreenSizesResponsivePO extends CommonPo {
    @FindBy(xpath = "//body/section[@id='tobi-ui-root']/div[1]")
    public WebElement ChatBox;
    @FindBy(xpath = "//*[@aria-label='Open mobile nav']")
    public WebElement BurgerMenu;
    @FindBy(linkText = "Network Status Checker")
    public WebElement NetworkChecker;

    public ScreenSizesResponsivePO(final WebDriver driver) {
        super(driver);
    }
}