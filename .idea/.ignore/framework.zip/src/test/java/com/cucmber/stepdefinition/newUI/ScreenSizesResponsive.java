package com.cucmber.stepdefinition.newUI;

import com.cucmber.core.WebDriverActions;
import com.cucmber.core.helper.ScumberException;
import com.cucmber.page.screenSizesResponsive.ScreenSizesResponsiveHelper;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;

import java.util.logging.Logger;

public class ScreenSizesResponsive {
    private final static Logger Log = Logger.getLogger(ScreenSizesResponsive.class.getName());

    private ScreenSizesResponsiveHelper screenSizesResponsive;
    private WebDriver itsDriver;

    public ScreenSizesResponsive() {
        Log.info("Constructor: Screen Sizes Responsive");
    }

    @Before
    public void before(final Scenario scenario)
            throws ScumberException {
        itsDriver = WebDriverActions.openBrowser(scenario);
        screenSizesResponsive = new ScreenSizesResponsiveHelper(itsDriver);
    }

    @Given("Chat Box Is In Desktop Mode")
    public void chatBoxIsInDesktopMode() {
        screenSizesResponsive.chatBoxIsInDesktopMode();
    }

    @Then("Desktop Mode Is Responsive")
    public void desktopModeIsResponsive() {
        screenSizesResponsive.desktopModeIsResponsive();
    }

    @When("Chat Box Is In Tablet Mode")
    public void chatBoxIsInTabletMode() {
        screenSizesResponsive.chatBoxIsInTabletMode();
    }

    @Then("Tablet Mode Is Responsive")
    public void tabletModeIsResponsive() {
        screenSizesResponsive.tabletModeIsResponsive();
    }

    @Given("Chat Box Is Opened In Mobile Size")
    public void chatBoxIsOpenedInMobileSize() {
        screenSizesResponsive.chatBoxIsOpenedInMobileSize();
    }

    @Then("Mobile Mode Is Responsive")
    public void chatBoxIsInFullscreenMode() {
        screenSizesResponsive.mobileModeIsResponsive();
    }
}