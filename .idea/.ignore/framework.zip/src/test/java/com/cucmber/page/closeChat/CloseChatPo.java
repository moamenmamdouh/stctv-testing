package com.cucmber.page.closeChat;

import com.cucmber.page.common.CommonPo;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CloseChatPo extends CommonPo {

    @FindBy(how = How.CSS, using = "[aria-label='Close Tobi chat']")
    WebElement close_CTA;

    public CloseChatPo(final WebDriver driver) {
        super(driver);
    }
}