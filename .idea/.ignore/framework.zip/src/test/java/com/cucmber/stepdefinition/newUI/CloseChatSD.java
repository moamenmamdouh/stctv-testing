package com.cucmber.stepdefinition.newUI;

import com.cucmber.core.WebDriverActions;
import com.cucmber.core.helper.ScumberException;
import com.cucmber.page.closeChat.CloseChatHelper;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;

import java.util.logging.Logger;

public class CloseChatSD {

    private final static Logger Log = Logger.getLogger(CloseChatSD.class.getName());

    private CloseChatHelper close_chat_helper;
    private WebDriver itsDriver;

    public CloseChatSD() {
        Log.info("Constructor: Close_Chat_sD");
    }

    @Before
    public void before(final Scenario scenario)
            throws ScumberException {
        itsDriver = WebDriverActions.openBrowser(scenario);
        close_chat_helper = new CloseChatHelper(itsDriver);
    }

    @When("customer click on close CTA")
    public void customer_click_on_close_CTA() {
        close_chat_helper.click_on_close_CTA();
    }

    @And("customer click on end CTA")
    public void customerClickOnEndCTA() {
        close_chat_helper.click_on_end_CTA();
    }

    @Then("validate chat close")
    public void validateChatClose() {
        close_chat_helper.validate_chat_closed();
    }

    @And("customer click on no CTA")
    public void customerClickOnNoCTA() {
        close_chat_helper.click_on_no_CTA();
    }

    @Then("validate chat not close")
    public void validateChatNotClose() {
        close_chat_helper.validate_chat_not_closed();
    }
}
