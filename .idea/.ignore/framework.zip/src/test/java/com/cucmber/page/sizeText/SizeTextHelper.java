package com.cucmber.page.sizeText;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.Assertions.assertNotEquals;

public class SizeTextHelper extends SizeTextPo {

    Dimension Actual_size;
    Dimension Size_After_change;

    public SizeTextHelper(final WebDriver driver) {
        super(driver);
    }

    public void Click_on_Three_Dot() {
        threeDots_CTA.click();
    }

    public void Click_on_change_Text_Size() {
        change_text_size_CTA.click();
    }

    public void Check_size_of_Text() {
        Actual_size = response_text.getSize();
    }

    public void compare_sizes_of_text() {
        Size_After_change = response_text.getSize();
        assertNotEquals(Size_After_change, Actual_size);
    }
}
