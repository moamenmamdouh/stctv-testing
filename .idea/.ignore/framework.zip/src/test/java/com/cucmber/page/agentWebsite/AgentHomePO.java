package com.cucmber.page.agentWebsite;

import com.cucmber.page.common.CommonPo;
import org.openqa.selenium.WebDriver;

public class AgentHomePO extends CommonPo {
    public AgentHomePO(WebDriver driver) {
        super(driver);
    }
}
