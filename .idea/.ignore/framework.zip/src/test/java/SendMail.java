import org.junit.jupiter.api.Test;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import java.util.Properties;

public class SendMail {

    @Test
    public void sendRunMail() {
        String host = "smtp.gmail.com";
        String username = "uk.testing.vis@gmail.com";
        String password = "dqqairjptbewdtlr";
        String d_port = "587";

        Properties props = new Properties();
        props.put("mail.smtp.user", username);
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.port", d_port);
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.debug", "true");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.ssl.trust", "smtp.gmail.com");
        props.put("mail.smtp.ssl.protocols", "TLSv1.2");

        Session session = Session.getDefaultInstance(props,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                });

        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(username));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress("aya.ahmed1@vodafone.com"));
            message.addRecipient(Message.RecipientType.CC, new InternetAddress("ali.adelsaeed@vodafone.com"));
            message.addRecipient(Message.RecipientType.CC, new InternetAddress("abanoub.hanin@vodafone.com"));
            message.addRecipient(Message.RecipientType.CC, new InternetAddress("mohammed.ahmedabdallah@vodafone.com"));
            message.setSubject("Tobi Automation Run CSV File");

            BodyPart messageBodyPart1 = new MimeBodyPart();
            messageBodyPart1.setText("Tobi Automation Run CSV File");

            MimeBodyPart messageBodyPart2 = new MimeBodyPart();

            String filename = "DailyRun.csv";
            DataSource source = new FileDataSource(filename);
            messageBodyPart2.setDataHandler(new DataHandler(source));
            messageBodyPart2.setFileName(filename);

            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messageBodyPart1);
            multipart.addBodyPart(messageBodyPart2);
            message.setContent(multipart);
            Transport.send(message);

            System.out.println("message sent....");
        } catch (MessagingException ex) {
            ex.printStackTrace();
        }
    }
}

