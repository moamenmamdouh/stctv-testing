import org.junit.jupiter.api.Test;
import vsts.VstsWrapper;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class GetFeature {

    @Test
    public void writeFeatureFile() throws IOException {
        VstsWrapper vstsWrapper = new VstsWrapper();
        List<Integer> ids = vstsWrapper.runSearchQuery();
        for (Iterator<Integer> i = ids.iterator(); i.hasNext(); ) {
            Integer workItemId = i.next();
            int code = vstsWrapper.getWorkItem(workItemId);
            if (code == 200) {
                vstsWrapper.addTags(workItemId);
            }
        }
    }
}
