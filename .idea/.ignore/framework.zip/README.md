# About Test Automation Framework

This framework is basically developed and designed to automate application product suite test cases.

# Work Flow

1. Create a branch
2. Do your work
3. Prepare feature / bug fix branch
4. Commit and push your work to your branch
5. Make sure commit history is clean
6. Raise pull request to merge your branch into the main repo branches

# Tools , Approaches and Technologies Used

* Java
* Selenium
* Cucumber
* Gherkin
* Junit 5
* Maven
* Allure cucumber report
* Rest-assured
* Page Object Model Design pattern

# How to Set up & Configure

1. Install IntelliJ (latest version)
2. Make sure that your VPN is switched off
3. Use IntelliJ git clone to download the automation framework to your local system
4. Get your id and password by opening this URL
   "https://vfuk-digital.visualstudio.com/Digital/_git/tobi-automation-testing"
   and clicking "Clone" button on the right side > "Generate Git Credentials"
   and copy the username and generated password to paste them in Intellij clone window
5. Install Gherkin and Cucumber for Java plugins
6. Open maven window and run "mvn clean install" command
7. Check whether the build is successful

# Configurations: Only for development purpose.

### To set your general configurations

1. Open [config.properties](config%2Fconfig.properties) file, set your desired URL to execute the automation framework
   on through the "application.url" value
2. Set the "remote" flag to false (To execute on your local machine)
3. Set the "local_driver" to the desired value (false will download and use the suitable remote driver, while true will
   use the specified local driver that exists in [resource](src%2Ftest%2Fjava%2Fresource) folder)

### To set your browser configurations

1. Open the [browser.properties](config%2Fbrowser.properties)
2. Set "browser" value to the desired browser (chrome or firefox)
3. Set the "dev.tools" to true if you want to open your browser with dev tools window open and network tab recording the
   logs in case you want to catch some traffic
4. If you want to use the framework without VPN, please follow the instructions
   in [browser.properties](config%2Fbrowser.properties)

### How to run feature specific tests

To run feature specific tests , please
edit [junit-platform.properties](src%2Ftest%2Fresources%2Fjunit-platform.properties) and update the tags "
cucumber.filter.tags=",
Example:

		cucumber.filter.tags=@ATHENA_DVT and @roamingbar

To start running the tagged scenarios please run
the [TestRunner.java](src%2Ftest%2Fjava%2Fcom%2Fcucmber%2Ftests%2FTestRunner.java) class.

###### Important Note: Please don't commit or push or try to merge the previous configurations into the master branch, make sure your pull requests don't contain any changes in these files.

